package furhatos.app.templatelinearskill.setting

import java.util.concurrent.TimeUnit

/** Engagement parameters */
const val MAX_NUMBER_OF_USERS = 1 // Max amount of people that Furhat will recognize as users simultaneously
const val DISTANCE_TO_ENGAGE = 1.0 // M6in distance for people to be recognised as users

val WAIT_TIME_TO_RESTART = TimeUnit.SECONDS.toMillis(30).toInt() //30 seconds
val WAIT_TIME_TIMEOUT = TimeUnit.MINUTES.toMillis(10).toInt() // 10 minutes