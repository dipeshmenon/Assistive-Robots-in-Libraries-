package furhatos.app.templatelinearskill.setting

import java.io.OutputStreamWriter
import java.net.Socket

class SocketConnection {

    fun sendData(host: String, port: Int, message: String) {
        val socket = Socket(host, port)
        val outputStream = socket.getOutputStream()
        val writer = OutputStreamWriter(outputStream)
        writer.write(message)
        writer.flush()
        writer.close()
        socket.close()
    }
}
