package furhatos.app.templatelinearskill.flow

import furhatos.app.templatelinearskill.nlu.WaitIntent
import furhatos.flow.kotlin.*

/** Universal button ta always be present **/
val UniversalWizardButtons = partialState {
    onButton("restart", color = Color.Red, section = Section.LEFT) {
        goto(Init)
    }
    onButton("Stop speaking", color = Color.Red, section = Section.LEFT) {
        furhat.stopSpeaking()
    }
    onButton("Return to Idle", color = Color.Yellow, section = Section.LEFT) {
        goto(Idle)
    }
}

/**
 * Buttons to include when navigating the linear flow.
 */
val NavigationButtons = partialState {
    onButton("Next", color = Color.Blue, section = Section.RIGHT) {
        goto(mainFlow.nextState(currentState))
    }
    onButton("Previous", color = Color.Blue, section = Section.RIGHT) {
        goto(mainFlow.previousState(currentState))
    }
    onButton("Pause", color = Color.Yellow, section = Section.RIGHT, instant = true) {
        furhat.stopListening() // when raising the continueIntent "manually" we need manually terminate the listen
        raise(WaitIntent())
    }
    onButton("TestInstant = true", color = Color.Yellow, section = Section.RIGHT, instant = true) {
        log.info("current state: " + currentState)
    }
    onButton("TestInstant = false", color = Color.Yellow, section = Section.RIGHT, instant = false) {
        log.info("current state: " + currentState)
    }
}