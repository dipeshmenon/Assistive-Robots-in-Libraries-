package furhatos.app.templatelinearskill.setting

import java.sql.*
import java.util.Properties

object DatabaseConnection {
    private const val jdbcUrl = "jdbc:mysql://localhost:3306/furhat_test"
    private const val username = "root"
    private const val password = "YOUR MQSQL PASSWORD"

    private val connectionProps = Properties()

    init {
        connectionProps["user"] = username
        connectionProps["password"] = password
    }

    fun getConnection(): Connection {
        return DriverManager.getConnection(jdbcUrl, connectionProps)
    }

    fun executeQuery(query: String): ResultSet? {
        var resultSet: ResultSet? = null
        try {
            val conn = getConnection()
            val statement = conn.createStatement()
            resultSet = statement.executeQuery(query)
        } catch (ex: SQLException) {
            ex.printStackTrace()
        }
        return resultSet
    }
}
