package furhatos.app.templatelinearskill.flow

import furhat.libraries.standard.BehaviorLib.AutomaticMovements
import furhatos.app.templatelinearskill.nlu.*
import furhatos.flow.kotlin.*
import furhatos.nlu.common.DontKnow
import furhatos.nlu.common.Maybe
import furhatos.nlu.common.No
import furhatos.nlu.common.Yes

/**
 * Our global parent to be used throughout the interaction
 */
val Global: State = state {
    include(UniversalWizardButtons)
}

/**
 * Our parent state for the active parts of the interaction.
 */
val Parent: State = state(Global) {
    include(AutomaticMovements.randomHeadMovements())

//    onResponse(listOf(Yes(), ContinueIntent(), Maybe(), DontKnow())) {// By default, Uncertain means yes.
//        furhat.say {
//            random {
//                +"Ok."
//                +"Ok!"
//            }
//        }
//        goto(mainFlow.nextState(currentState))
//    }
//    onResponse<No> {
//        furhat.say {
//            random {
//                +"No worries. "
//                +"No problem. "
//            }
//        }
//        furhat.attendNobody()
//        delay(5000)
//        goto(Idle)
//    }
//    onResponse(listOf(WaitIntent(), StopTalkingIntent(), NotTalkingToYouIntent())) {
//        call(Wait)
//        goto(mainFlow.nextState(currentState))
//    }
//    onResponse {// By default, go to next state whenever a user says something.
//        if (users.hasAny()) { // But check that we still have a user present!
//            goto(mainFlow.nextState(currentState))
//        } else {
//            log.info("No users around. Returning to Idle")
//            goto(Idle)
//        }
//    }
//    onNoResponse {// By default, go to next state even if the user is just silent.
//        if (users.hasAny()) { // But check that we still have a user present!
//            goto(mainFlow.nextState(currentState))
//        } else {
//            log.info("No users around. Returning to Idle")
//            goto(Idle)
//        }
//    }
}
