package furhatos.app.templatelinearskill.flow

import furhatos.app.templatelinearskill.flow.main.End
import furhatos.app.templatelinearskill.flow.main.PartTwo
import furhatos.app.templatelinearskill.flow.main.Start
import furhatos.flow.kotlin.State
import furhatos.flow.kotlin.dialogLogger
import java.util.logging.Logger

// Initialize logger
val flowLog = Logger.getLogger("FlowLogger")

/**
 * Defines the order the flow is executed in.
 */
val mainFlow = Flow(
    listOf(
        Start,
        PartTwo,
        End
    )
)

/**
 * Class to define a simple linear flow. Essentially a list of states.
 */
class Flow(val states: List<State>) {

    // Start logging session at the beginning of the flow
    init {
        dialogLogger.startSession(
            name = "MainFlowSession",
            maxLength = 600,
            cloudToken = "09838c47-3cdf-425c-a12c-03a747e084c8\n"
        )
    }

    fun startState(): State {
        return states.first()
    }

    fun endState(): State {
        // End logging session when the flow ends
        dialogLogger.endSession()
        return states.last()
    }

    fun nextState(curState: State): State {
        return when {
            !states.contains(curState) -> { // No state in list
                flowLog.warning("Trying to go \"next\" state from a state outside of the flow.")
                flowLog.info("Returning to Idle")
                Idle
            }
            curState == endState() -> { // Invalid state in list
                flowLog.warning("Trying to go \"next\" state from end of the flow.")
                flowLog.info("Returning to EndState")
                endState()
            }
            else -> { // valid states
                val gotoState = states[states.indexOf(curState) + 1]
                flowLog.info("goto $gotoState")
                gotoState
            }
        }
    }

    fun previousState(curState: State): State {
        return when {
            !states.contains(curState) -> { // No state in list
                flowLog.warning("Trying to go \"previous\" state from a state outside of the flow.")
                flowLog.info("Returning to Idle")
                Idle
            }
            curState == startState() -> { // invalid state in list
                flowLog.warning("Trying to go \"previous\" state from start of the flow.")
                flowLog.info("Returning to StartState")
                startState()
            }
            else -> { // valid state
                val gotoState = states[states.indexOf(curState) - 1]
                flowLog.info("goto $gotoState")
                gotoState
            }
        }
    }
}