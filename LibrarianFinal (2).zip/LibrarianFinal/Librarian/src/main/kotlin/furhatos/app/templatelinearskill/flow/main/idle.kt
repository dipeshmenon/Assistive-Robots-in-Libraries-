package furhatos.app.templatelinearskill.flow

import furhatos.app.templatelinearskill.nlu.*
import furhatos.app.templatelinearskill.setting.WAIT_TIME_TIMEOUT
import furhatos.app.templatelinearskill.setting.WAIT_TIME_TO_RESTART
import furhatos.flow.kotlin.*
import furhatos.flow.kotlin.Color
import furhatos.nlu.common.*
import furhatos.records.Location

/**
 * Idle state to wait for users before starting the interaction.
 */
val Idle: State = state(Global) {
    onEntry {
        furhat.attendNobody()
    }

    onUserEnter {
        furhat.attend(it)
        goto(mainFlow.startState())
    }
    onUserLeave {
        when { // "it" is the user that left
            !users.hasAny() -> furhat.attendNobody() // no more users
            furhat.isAttending(it) -> furhat.attend(users.other) // current user left
            else -> furhat.glance(it.head.location) // other user left, just glance
        }
    }

}

/**
 * Waiting state for the user to pause the interaction.
 */
val Wait: State = state(Global) {
    onEntry {
        furhat.say {
            random {
                +"Okay. "
                +"Sure. "
                +""
            }
            random {
                +"I'll wait. "
                +"I'll wait for now"
                +"I'll be here when you need me."
                +"I'm here when you need me. "
            }
        }
        furhat.attendNobody()
        furhat.attend(Location.DOWN)
        furhat.listen()
    }
    onReentry {
        furhat.listen()
    }
    onResponse<ContinueIntent> {
        if (call(VerifyContinue()) as Boolean) { // Verify that the user really wanted to resume the interaction
            terminate()
        } else reentry()
    }
    onResponse {
        reentry()
    }
    onNoResponse {
        reentry()
    }
    onButton("Continue", color = Color.Green, section = Section.RIGHT) {
        furhat.stopListening() // when raising the continueIntent "manually" we need manually terminate the listen
        raise(ContinueIntent())
    }
}

/**
 * State to verify user really wanted to wake the robot up and continue
 */
fun VerifyContinue(): State = state(Global) {
    onEntry {
        when {
            users.hasAny() -> furhat.attend(users.userClosestToPosition(Location.ORIGIN)) // look at the closest user
            !users.hasAny() -> furhat.attend(Location.STRAIGHT_AHEAD) // look up even if there are no users in the field of view
        }
        furhat.ask {
            random {
                +"Do you want to continue now?"
                +"Do you want me to continue?"
                +"Should we resume? "
                +"Should we resume again?"
            }
        }
    }
    onResponse(listOf(Yes(), ContinueIntent(), WakeUpIntent())) {
        terminate(true)
    }
    onResponse(listOf(No(), Maybe(), DontKnow(), WaitIntent(), StopTalkingIntent(), NotTalkingToYouIntent())) {
        terminate(false)
    }
    onResponse {
        terminate(false) // Other response = no
    }
    onNoResponse {
        terminate(false) // No response = no
    }
    onButton("Yes", color = Color.Green, section = Section.RIGHT) {
        furhat.stopListening() // when raising an intent manually we need manually terminate the listen
        raise(Yes())
    }
    onButton("No", color = Color.Green, section = Section.RIGHT) {
        furhat.stopListening() // when raising an intent manually we need manually terminate the listen
        raise(No())
    }
    onTime(delay = WAIT_TIME_TIMEOUT, instant = true) { // Ten minutes timeout
        log.info("Timed out (${WAIT_TIME_TIMEOUT} minutes) in waiting state")
        log.debug("Returning to Idle")
        goto(Idle)
    }
}

/**
 * Waiting room to restart the interaction or return to Idle
 */
fun returnToIdle(): State = state(Global) {
    onEntry {
        furhat.listen()
    }
    onReentry {
        furhat.listen()
    }
    onResponse(listOf(StartIntent(), ContinueIntent(), Greeting(), WakeUpIntent())) {
        terminate(false)
    }
    onResponse {
        reentry()
    }
    onNoResponse {
        reentry()
    }
    onUserLeave {
        terminate(true)
    }
    onUserEnter {
        terminate(false)
    }
    onTime(delay = WAIT_TIME_TO_RESTART) { // After some time, we will return to Idle.
        terminate(true)
    }
}