package furhatos.app.templatelinearskill.setting

import furhatos.flow.kotlin.FlowControlRunner
import furhatos.flow.kotlin.furhat
import furhatos.flow.kotlin.voice.PollyNeuralVoice
import furhatos.flow.kotlin.voice.Voice

/**
 * Class to set a persona for an interaction.
 */
class Persona(val name: String, val mask: String = "adult", val face: List<String>, val voice: List<Voice>)

fun FlowControlRunner.activate(persona: Persona) {
    for (voice in persona.voice) {
        if (voice.isAvailable) {
            furhat.voice = voice
            break
        }
    }

    for (face in persona.face) {
        if (furhat.faces[persona.mask]?.contains(face)!!) {
            furhat.character = face
            break
        }
    }
}

/**
 * Define your persona for your interaction.
 * Set a voice and face. Extend the Persona class to add more traits to your persona.
 */

val furhatPersona = Persona(
    name = "Furhat",
    face = listOf(
        "Alex",
        "default"), // Backup if Alex is not available
    voice = listOf(
        PollyNeuralVoice.Matthew(),
        PollyNeuralVoice.Joanna()
    ).shuffled() // The furhat persona is either male/female, so we randomize what voice to select
)