package furhatos.app.templatelinearskill.flow.main
import furhatos.app.templatelinearskill.flow.*
import furhatos.app.templatelinearskill.flow.main.GlobalState.entitiesString
import furhatos.app.templatelinearskill.flow.main.GlobalState.locationNum
import furhatos.app.templatelinearskill.nlu.*
import furhatos.app.templatelinearskill.setting.DatabaseConnection
import furhatos.flow.kotlin.*
import furhatos.nlu.common.No
import java.time.LocalTime
import furhatos.nlu.common.Thanks
import furhatos.nlu.common.Yes
import java.io.OutputStreamWriter
import java.net.Socket
import java.time.LocalDate
import java.util.*
import kotlin.random.Random
import org.apache.commons.text.similarity.LevenshteinDistance

fun sendLocationNo(locationNo: String) {
    val host = "192.168.242.1"
    val port = 12345

    val socket = Socket(host, port)
    val outputStream = socket.getOutputStream()
    val writer = OutputStreamWriter(outputStream)
    writer.write(locationNo) // Directly send the provided location number
    writer.flush()
    writer.close()
    outputStream.close()
    socket.close()
}


fun computeLevenshteinSimilarity(str1: String, str2: String): Double {
    val distance = LevenshteinDistance()
    val similarity = 1.0 - (distance.apply(str1, str2).toDouble() / Math.max(str1.length, str2.length))
    return similarity
}

object GlobalState {
    var interactionCount: Int = 0
    var entitiesString: String = ""
    var hinteractionCount: Int = 0
    var locationNum: String = ""
}

val Start: State = state(Parent) {
    include(NavigationButtons)

    onEntry {

        val currentTime = LocalTime.now()
        val currentHour = currentTime.hour
        val greeting = when (currentHour) {
            in 0..11 -> "Good morning!"
            in 12..15 -> "Good afternoon!"
            in 16..20 -> "Good evening!"
            else -> "Greetings!"
        }
        furhat.say(greeting)
        GlobalState.interactionCount = 0
        val iutr = listOf("Hello! I'm Furhat, your friendly neighborhood librarian, here to assist you.",
            "Hi there, I'm Furhat, your dedicated librarian.",
            "Greetings! I'm Furhat, your neighborhood librarian, ready to support you with whatever you need.",
            "Hello, I'm Furhat, your local librarian, here to help you out.",
            "Hi, I'm Furhat, your helpful librarian.",
            "Good day! I'm Furhat, your neighborhood librarian, eager to offer my assistance.",
            "Hello! I'm Furhat, your knowledgeable librarian, here to help you find what you need.",
            "Hi, I'm Furhat, your attentive librarian, ready to provide assistance.",
            "Hello, I'm Furhat, your resourceful librarian.",
            "Hi there! I'm Furhat, your committed librarian, here to support you."
        )
        val irandomIndex = Random.nextInt(iutr.size)
        val irandomutr = iutr[irandomIndex]
        furhat.say(irandomutr)
        delay(1000)
        furhat.say("Welcome to our Central Library!")
        delay(500)
        val serviceutr = listOf("I can help you with various tasks such as providing information about our library services, " +
                "timings, borrowing policies, and membership. If you need to find a specific book or know where it's located, just ask! " +
                "I can also tell you about available genres, authors, subjects, and even suggest similar books. " +
                "Curious about the most popular or recently added books? I’ve got you covered. Plus, I can inform you about ongoing events and chat with you",
                "I can provide information on library services, operating hours, borrowing policies, " +
                "and membership. Looking for a specific book or its location? I can help. I also know about available genres, authors, subjects, and can recommend similar books. " +
                "Ask me about the most popular or recently added books, or any ongoing events. I’m here for this friendly chat.",
            "I can guide you on library services, timings, borrowing policies, and membership details. If you need to find a book, " +
            "know where it’s located, or learn about available genres, authors, and subjects, just let me know. I can suggest books, tell you about popular and newly added ones, " +
            "and update you on events.",
            "I can provide information about our services, operating hours, borrowing policies, and " +
            "how to become a member. If you need assistance finding a book, knowing its location, or exploring available genres, authors, and subjects, I'm here for you. " +
            "I can also recommend books, inform you about popular and new arrivals, and update you on library events?"
        )
        val servicerandomIndex = Random.nextInt(serviceutr.size)
        val servicerandomutr = serviceutr[servicerandomIndex]
        furhat.say(servicerandomutr)
        delay(1000)
        furhat.say("Please use the word 'Author' before referring to an author's name, and use the word 'Book' before referring to a book's name. Thank you!")
        goto(PartTwo)
    }

}

val PartTwo: State = state(Parent) {
    include(NavigationButtons)

    onEntry {
        if (GlobalState.interactionCount>=1){
            reentry()
        }
        val firstaskutr = listOf("So how can I help you, today?", "How may I assist you today?", "What can I do for you today?",
            "How can I be of service to you today?", "What brings you here today? How can I help?",
            "Is there something I can help you with today?", "How can I assist you on this fine day?",
            "What do you need assistance with today?", "How may I support you today?", "Is there anything I can do for you today?",
            "How can I assist you at this moment?")
        val farandomIndex = Random.nextInt(firstaskutr.size)
        val farandomutr = firstaskutr[farandomIndex]
        furhat.say(farandomutr)
        furhat.listen(timeout = 4000)
    }

    onReentry {
        if(GlobalState.interactionCount>2){
            furhat.listen(timeout = 4000)
        }

        val utr = listOf("Is there anything else you need assistance with?", "Can I help you with anything else?",
            "Do you need help with anything else?", "Is there anything else you require help with?", "Anything more I can assist you with?",
            "What else can I help you with?", "Is there any other way I can assist you?", "Do you need any further assistance?",
            "Is there something else I can do for you?", "How else can I be of service?", "Is there any additional help you need?",
            "Can I assist you with anything further?", "Anything else you need my help with?", "Is there another way I can help you?",
            "Do you have any other questions or needs?", "Anything else I can do for you today?", "Is there any other support you require?",
            "How else may I assist you?", "Can I offer help with anything else?", "Is there any more assistance you need?")
        val randomIndex = Random.nextInt(utr.size)
        val randomutr = utr[randomIndex]
        furhat.say(randomutr)
        furhat.listen(timeout = 4000)
    }

    onResponse(GreetingsLib()){
        val greetingsutr = listOf("Hello!", "Hi there!", "Hey!", "Greetings!", "Hello!",
            "Hi there!", "Hey there!", "Hola!", "Bonjour!", "Ciao!", "Namaste!", "Salam!",
            "Aloha", "Konnichiwa!", "Guten Tag!", "Sup!", "Pleased to meet you!",
            "Lovely day, isn't it?", "Good morning!", "Good afternoon!", "Good evening!",
            "Greetings!", "Howdy-do!", "Hi there!", "Well, hello there!", "Nice to see you!",
            "Good to see you again!", "Good to meet you!", "Nice to meet you!", "Hey, nice to see you!",
            "Hey, good to see you!", "Hello again!", "Hi, nice to see you!")
        val greetingsrandomIndex = Random.nextInt(greetingsutr.size)
        val greetingsrandomutr = greetingsutr[greetingsrandomIndex]
        furhat.say(greetingsrandomutr)

        GlobalState.interactionCount = 1
        reentry()
    }

    onResponse(LibServices()){
        goto(LServices)
    }

    onResponse(LibraryTimings()) {
        goto(LInfo)
    }

    onResponse(LibPolicies()){
        goto(LPolicies)
    }

    onResponse(LibRR()){
        goto(LRR)
    }

    onResponse(LibMemAvail()){
        goto(LMemAvail)
    }


//    onResponse(LibEvents()){
//        goto(LEvents)
//    }

    onResponse(BookLocationIntent()){
        entitiesString = it.intent.getEntities().toString()
        goto(LBookLocation)
    }

    onResponse(BookGenreIntent){
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(BGenre)
    }

    onResponse(BookAuthorIntent){
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(BAuthor)
    }

    onResponse(BookSubjectIntent){
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(BSubject)
    }

    onResponse(BookKeywordIntent){
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(BKeyword)
    }

    onResponse(ListGenreAvail()) {
        goto(ListGenresState)
    }

    onResponse(ListAuthorAvail()) {
        goto(ListAuthorsState)
    }

    onResponse(ListSubjectsAvail()){
        goto(ListSubjectsState)
    }

    onResponse(CurrentTimeLib()){
        goto(CurrentTimeState)
    }

    onResponse(MostRenewedGenreIntent){
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(MostRenewedBooksGenre)
    }

    onResponse(MostRenewedSubjectIntent) {
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(MostRenewedBooksSubject)
    }

    onResponse(MostRenewedAuthorIntent) {
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(MostRenewedBooksAuthor)
    }

    onResponse(MostRenewedBooksKeywordIntent) {
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(MostRenewedBooksKeyword)
    }

    onResponse(BookNameGenreIntent) {
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(BookNameGenre)
    }

    onResponse(BookNameSubjectIntent) {
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(BookNameSubject)
    }

    onResponse(BooksByLocationIntent) {
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(BooksByLocationNumber)
    }

    onResponse(BookInfoIntent) {
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(BookInfo)
    }

    onResponse(TotalBookLib()) {
        goto(TotalBooksCount)
    }
////////////////////////////////////////////////////////////////////////////////
    onResponse(RecentBooksLib()) {
        goto(ListRecentBooksState)
    }

    onResponse(RecentBooksByAuthorIntent) {
        entitiesString = it.intent.getEntities().toString()
        goto(ListRecentBooksByAuthorState)
    }

    onResponse(RecentBooksByGenreIntent) {
        entitiesString = it.intent.getEntities().toString()
        goto(ListRecentBooksByGenreState)
    }

    onResponse(RecentBooksBySubjectIntent) {
        entitiesString = it.intent.getEntities().toString()
        goto(ListRecentBooksBySubjectState)
    }

    onResponse(RecentBooksByKeywordIntent) {
        entitiesString = it.intent.getEntities().toString()
        goto(ListRecentBooksByKeywordState)
    }

    onResponse(OngoingEventsLib()) {
        goto(ListOngoingEventsState)
    }

    onResponse(RecentlyConcludedEventsLib()) {
        goto(ListRecentlyConcludedEventsState)
    }

    onResponse(UpcomingEventsLib()) {
        goto(ListUpcomingEventsState)
    }
//////////////////////////////////////////////////////////////////////////////////////
    onResponse(BookSimilarityIntent){
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(BSimilarity)
    }

    onResponse(FurServices()){
        goto(FServices)
    }

    onResponse(HowQUTF()){
        goto(HQTF)
    }

    onResponse(HaveLocQUTF()){
        goto(HLocQUTF)
    }

    onResponse(FinishProj()){
        goto(FProj)
    }

    onResponse(BingeWatch()){
        goto(BWatch)
    }

    onResponse(HobbyAsk()){
        goto(HAsk)
    }

    onResponse(AgeAsk()){
        goto(AAsk)
    }

    onResponse(GenderAsk()){
        goto(GAsk)
    }

    onResponse(FunAsk()){
        goto(FAsk)
    }

    onResponse(UnavailableIntent){
        entitiesString = ""
        entitiesString = it.intent.getEntities().toString()
        goto(UnavailableState)
    }

    onResponse(Yes()){
        reentry()
    }

//    onResponse(No()){
//
//        val farutr = listOf("Thank You! Have a nice day!", "Thank you! Enjoy the rest of your day!",
//            "Thanks! Wishing you a wonderful day!", "Thank you! Have a great day ahead!",
//            "Thanks a lot! Hope you have a pleasant day!", "Thank you! Take care and have a good day!",
//            "Thanks! May your day be fantastic!", "Thank you! Have an amazing day!", "Thanks! Have a delightful day!",
//            "Thank you! Hope the rest of your day is splendid!", "Thank you! Make the most of your day!")
//        val currentTime = LocalTime.now()
//        val currentHour = currentTime.hour
//        val updatedFarutr = if (currentHour > 20) {
//            farutr.map { it.replace("day", "night") }
//        } else {
//            farutr
//        }
//        val farrandomIndex = Random.nextInt(updatedFarutr.size)
//        val farrrandomutr = updatedFarutr[farrandomIndex]
//        furhat.say(farrrandomutr)
//        goto(End)
//    }

    onResponse(EndInteraction()){
        val farutr = listOf("Thank You! Have a nice day!", "Thank you! Enjoy the rest of your day!",
            "Thanks! Wishing you a wonderful day!", "Thank you! Have a great day ahead!",
            "Thanks a lot! Hope you have a pleasant day!", "Thank you! Take care and have a good day!",
            "Thanks! May your day be fantastic!", "Thank you! Have an amazing day!", "Thanks! Have a delightful day!",
            "Thank you! Hope the rest of your day is splendid!", "Thank you! Make the most of your day!")
        val currentTime = LocalTime.now()
        val currentHour = currentTime.hour
        val updatedFarutr = if (currentHour > 20) {
            farutr.map { it.replace("day", "night") }
        } else {
            farutr
        }
        val farrandomIndex = Random.nextInt(updatedFarutr.size)
        val farrrandomutr = updatedFarutr[farrandomIndex]
        furhat.say(farrrandomutr)
        goto(End)
    }

    onResponse(){
        val othutr = listOf("Sorry! I did not understand that!", "I'm sorry, I didn't quite catch that.",
            "Apologies, I didn't understand what you meant.", "I'm afraid I didn't get that, can you please clarify?",
            "Sorry, I didn't follow that.", "I didn't understand that",
            "Oops, I missed that", "My apologies, but I didn't comprehend that.",
            "I didn't quite get that", "Sorry, that went over my head")
        val othrandomIndex = Random.nextInt(othutr.size)
        val othrandomutr = othutr[othrandomIndex]
        furhat.say(othrandomutr)
        reentry()
    }
    onNoResponse {
        reentry()
    }
    onResponse(Thanks()){
        reentry()
    }
}

val LServices: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val lsutr = listOf("We offer printing, scanning, as well as access to online resources via a computer",
            "We provide services for printing, scanning, and accessing online resources through our computers.",
            "Our offerings include printing, scanning, and computer access to online resources.",
            "You can use our facilities for printing, scanning, and online resource access via computer.",
            "We have printing and scanning services available, as well as computer access to various online resources.",
            "Our services include printing, scanning, and using computers to access online resources.",
            "We offer printing, scanning, and access to online resources through our computers.",
            "You can take advantage of our printing, scanning, and computer access to online resources.",
            "We provide printing and scanning, along with computer-based access to online resources.",
            "You can print, scan, and access online resources using our computers.",
            "We offer various services including printing, scanning, and computer access to online resources.")
        val lsrandomIndex = Random.nextInt(lsutr.size)
        val lsrandomutr = lsutr[lsrandomIndex]
        furhat.say(lsrandomutr)

        goto(PartTwo)
    }
}

val LPolicies: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val borutr = listOf( "Patrons can borrow up to 3 items for 3 weeks with renewals available. BTech students must return books within 15 days, MTech within 30 days. Late returns incur fines: 10 rupees/day for the first week, then 20 rupees/day.",
            "You can check out up to 3 items for 3 weeks, with renewal options. BTech students return books in 15 days, MTech in 30 days. Fines for late returns: 10 rupees/day for the first week, 20 rupees/day thereafter.",
            "Borrow up to 3 items for 3 weeks, with the option to renew. BTech students have 15 days, MTech have 30 days to return books. Late returns will incur fines: 10 rupees/day for the first week, 20 rupees/day after that.",
            "Our policy allows up to 3 items for 3 weeks, with possible renewals. BTech students must return books in 15 days, MTech in 30 days. Fines: 10 rupees/day for the first week, then 20 rupees/day.",
            "Check out up to 3 items for 3 weeks, with the option to renew. BTech students have 15 days, MTech have 30 days to return books. Late returns incur fines of 10 rupees/day for the first week, then 20 rupees/day.")
        val borrandomIndex = Random.nextInt(borutr.size)
        val borrandomutr = borutr[borrandomIndex]
        furhat.say(borrandomutr)

        goto(PartTwo)
    }
}

val LInfo: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val linfoutr = listOf(   "The library is open from 9 AM to 9 PM from Monday to Friday, and from 10 AM to 6 PM on Saturdays.",
            "Our library operates from 9 in the morning until 9 in the evening on weekdays, and from 10 AM to 6 PM on Saturdays.",
            "You can visit the library from 9 AM to 9 PM on weekdays and from 10 AM to 6 PM on Saturdays.",
            "The library hours are 9 AM to 9 PM, Monday through Friday, and 10 AM to 6 PM on Saturdays.",
            "We are open from 9 AM to 9 PM during the week and from 10 AM to 6 PM on Saturday.")
        val linforandomIndex = Random.nextInt(linfoutr.size)
        val linforandomutr = linfoutr[linforandomIndex]
        furhat.say(linforandomutr)

        goto(PartTwo)
    }
}


val LRR: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val lrrutr = listOf("You can both renew as well as return your borrowed items at the circulation desk. ",
            "Both renewals and returns of borrowed items can be done at the circulation desk.",
            "You have the option to renew or return your borrowed items directly at the circulation desk.",
            "At the circulation desk, you can both renew and return any items you've borrowed.",
            "Renewing or returning your borrowed items is conveniently done at the circulation desk.",
            "For your convenience, both renewing and returning borrowed items can be handled at the circulation desk.",
            "You can perform both renewals and returns of borrowed items at our circulation desk.",
            "At the circulation desk, you have the ability to renew as well as return any borrowed items.",
            "Both renewing and returning your borrowed items can be completed at the circulation desk.",
            "At the circulation desk, you can renew items you've borrowed as well as return them.",
            "The circulation desk is where you can both renew and return any borrowed items.")
        val lrrrandomIndex = Random.nextInt(lrrutr.size)
        val lrrrandomutr = lrrutr[lrrrandomIndex]
        furhat.say(lrrrandomutr)

        goto(PartTwo)
    }
}

val LMemAvail: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val memavutr = listOf("To become a member, simply visit our circulation desk with a valid form of identification and proof of address. " +
                "Membership benefits include access to our extensive collection of books, online resources, and participation in library programs and events. " +
                "Our staff will be happy to assist you in the registration process.", "Becoming a member is easy—just stop by our circulation desk with a " +
                "valid ID and proof of address. Enjoy perks like access to our wide book collection, online resources, and participation in library events. " +
                "Our friendly staff will guide you through the registration.", "Simply visit our circulation desk with a valid ID and proof of address to join. " +
                "Membership brings access to our diverse book collection, online resources, and engagement in library programs. Let our team help you with the " +
                "registration process.", "To sign up, visit our circulation desk with a valid ID and proof of address. Membership entitles you to explore our " +
                "extensive book selection, online resources, and involvement in library activities. Our team is ready to assist you with registration.",
            "Joining is a breeze—just come by our circulation desk with a valid ID and proof of address. Enjoy the benefits of membership, including access " +
                    "to our vast book collection, online resources, and participation in library programs. Our staff is here to help with registration.",
            "Visit our circulation desk with a valid ID and proof of address to become a member. Enjoy perks like access to our broad book collection, " +
                    "online resources, and engagement in library events. Let our team assist you with the registration process.", "Become a member by visiting our " +
                    "circulation desk with a valid ID and proof of address. Membership includes access to our extensive book collection, online resources, and " +
                    "participation in library programs. Our staff will guide you through registration.", "To become a member, stop by our circulation desk with a " +
                    "valid ID and proof of address. Membership offers access to our diverse book collection, online resources, and involvement in library events. " +
                    "Let our team assist you with the registration.", "Simply drop by our circulation desk with a valid ID and proof of address to sign up for " +
                    "membership. Enjoy access to our wide array of books, online resources, and library programs. Our staff is ready to help you through the " +
                    "registration process.", "Join us by visiting our circulation desk with a valid ID and proof of address. Membership comes with benefits " +
                    "such as access to our extensive book collection, online resources, and participation in library activities. Allow our team to assist you in " +
                    "registering.", "Ready to become a member? Just come by our circulation desk with a valid ID and proof of address. Membership perks include " +
                    "access to our vast book collection, online resources, and involvement in library programs. Our team is here to make the registration process " +
                    "smooth for you.")
        val memavrandomIndex = Random.nextInt(memavutr.size)
        val memavrandomutr = memavutr[memavrandomIndex]
        furhat.say(memavrandomutr)

        goto(PartTwo)
    }
}

val LEvents: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val leveutr = listOf("Sure, here are the events currently happening at IIT Mandi:", "Of course! Here's a list of the ongoing events:",
            "Absolutely! These are the events taking place right now at IIT Mandi:", "Sure thing! Take a look at the events happening currently:",
            "No problem! Here are the events that are happening now at IIT Mandi:", "I'd be happy to help. Here are the events going on at the moment:",
            "Certainly! Here’s what’s happening right now at IIT Mandi:", "Here are the events currently in progress:",
            "Alright! Here’s a list of events happening at the moment at IIT Mandi:", "Here are the events taking place currently for you to check out:")
        val leverandomIndex = Random.nextInt(leveutr.size)
        val leverandomutr = leveutr[leverandomIndex]
        furhat.say(leverandomutr)

        val resultSet = DatabaseConnection.executeQuery("SELECT * FROM EVENTS")
        // Iterate over the rows in the result set and print each row
        while (resultSet != null && resultSet.next()) {
            val Ename = resultSet.getString("Ename")
            furhat.say(Ename)
        }

        goto(PartTwo)
    }
}

val LBookLocation: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val startIndex = entitiesString.indexOf('=') + 1
        var extractedString = entitiesString.substring(startIndex).trim()
        if (extractedString.endsWith("}")) {
            extractedString = extractedString.removeSuffix("}")
        }
        var Bname = extractedString
        println(Bname)

        // Retrieve authors from the database
        val booksFromDatabase: MutableList<String> = mutableListOf()
        val resultSetBookNames = DatabaseConnection.executeQuery("SELECT DISTINCT Bname FROM BOOKS")
        if (resultSetBookNames != null) {
            while (resultSetBookNames.next()) {
                val dbBook = resultSetBookNames.getString("Bname")
                booksFromDatabase.add(dbBook)
            }
        }

        var maxSimilarity = 0.0
        var mostSimilarBook = Bname
        for (dbBook in booksFromDatabase) {
            val similarity = computeLevenshteinSimilarity(Bname, dbBook)
            println("Similarity between '$Bname' and '$dbBook': $similarity")
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                mostSimilarBook = dbBook
            }
        }


        val similarityThreshold = 0.7


        if (maxSimilarity >= similarityThreshold) {
            Bname = mostSimilarBook
        }

        var locationNo: String? = null


        val resultSet = DatabaseConnection.executeQuery("SELECT location_no FROM BOOKS WHERE Bname = '$Bname'")


        if (resultSet != null && resultSet.next()) {
            // Retrieve the location_no from the result set
            locationNo = resultSet.getString("location_no")
        }


        println("Location number for $Bname: $locationNo")


        if (locationNo != null) {
            val booklavutr = listOf(
                "$Bname is available! The location number for it is $locationNo",
                "$Bname is in stock! It's located at location number $locationNo.",
                "We have $Bname available, and it's located at location number $locationNo.",
                "$Bname is ready for you! Find it at location number $locationNo.",
                "Interesting choice! We have $Bname in our inventory! Look for it at location number $locationNo.",
                "$Bname is currently available. You can find it at location number $locationNo.",
                "Good choice! We've got $Bname! It's waiting for you at location number $locationNo.",
                "$Bname is here, and it's at location number $locationNo.",
                "$Bname is located at $locationNo.",
                "$Bname is in stock and ready to go! Look for it at location number $locationNo.",
                "We just received $Bname! You can find it at location number $locationNo."
            )
            locationNum = locationNo
            val booklavrandomIndex = Random.nextInt(booklavutr.size)
            val booklavrandomutr = booklavutr[booklavrandomIndex]
            furhat.say(booklavrandomutr)

            furhat.say("Do you want Turtle to take you to the location? Yes or No?")
            goto(turtleorfurtle)
//            try {
//                sendLocationNo(locationNo) // for this the python script receiving the location no from Misty has to be running, hence for now it is commented
//                goto(End)
//            } catch (e: Exception) {
//                // Log the exception if needed
//                println("Failed to send location number: ${e.message}")
//            }
//            furhat.say("Turtlebot please take our friend here to $locationNo")
//
//            goto(PartTwo)
        }

        val bookluavutr = listOf("This book does not exist in our library", "The book does not exist in our library", "We don't have $Bname in our library.",
            "$Bname isn't in our library's collection.", "Unfortunately, $Bname isn't available here.", "I'm sorry, but we don't have $Bname in our inventory.",
            "$Bname is not part of our library's holdings.", "We don't carry $Bname in our library.", "I'm afraid $Bname is not in stock at our library.",
            "Sorry, but $Bname isn't among our library's resources.", "Unfortunately, we do not possess $Bname in our library.",
            "Regrettably, $Bname is not available within our library's selection.", "$Bname does not exist in our library!")
        val bookluavrandomIndex = Random.nextInt(bookluavutr.size)
        val bookluavrandomutr = bookluavutr[bookluavrandomIndex]
        furhat.say(bookluavrandomutr)

        goto(PartTwo)
    }
}

val turtleorfurtle: State = state(Parent){
    onEntry {
        GlobalState.hinteractionCount = 0
        GlobalState.hinteractionCount++
        furhat.listen(timeout = 4000)
    }
    onResponse(Yes()) {
        //furhat.say("That's good to hear. In this day and age of edgy-Nihilism, a happy person as rare a sight as would be a dinosaur with a toothpick")
        val turtleutr = listOf("Turtlebot, please guide our friend to $locationNum.",
            "Turtlebot, take our guest to the specified $locationNum.",
            "Turtlebot, please escort our friend to $locationNum",
            "Turtlebot, lead our guest to $locationNum they requested.",
            "Turtlebot, kindly take our friend to $locationNum",
            "Turtlebot, navigate our guest to $locationNum.",
            "Turtlebot, please bring our friend to $locationNum.",
            "Turtlebot, direct our guest to $locationNum.",
            "Turtlebot, show our friend the way to $locationNum",
            "Turtlebot, please transport our friend to $locationNum."
        )
        val turtlerandomIndex = Random.nextInt(turtleutr.size)
        val turtlerandomutr = turtleutr[turtlerandomIndex]
        val regex = """.\d: (\d+)\.""".toRegex()
        val matchResult = regex.find(locationNum)
        val extractedLocationNo = matchResult?.groups?.get(1)?.value ?: ""

        println("Extracted location number: $extractedLocationNo") // For debugging purposes
        try {
            sendLocationNo(extractedLocationNo) // for this the python script receiving the location no from Misty has to be running, hence for now it is commented
            goto(End)
        } catch (e: Exception) {
            // Log the exception if needed
            println("Failed to send location number: ${e.message}")
        }
        furhat.say(turtlerandomutr)

        goto(PartTwo)
    }
    onResponse(No()) {
        val furtleutr = listOf(
            "You got it! Safe travels to your destination. Farewell!",
            "Sure thing! Have a smooth journey to your location. Take care!",
            "Of course! Best of luck getting there. Goodbye!",
            "Alright, you can head there on your own. Farewell and take care!",
            "Absolutely! Wishing you a safe trip to your location. Bye for now!",
            "No problem! Enjoy your walk to the spot. See you later!",
            "Sure, you can go ahead. Have a great time. Goodbye!",
            "Okay! Hope you find it easily. Farewell and stay safe!",
            "Alright then, you’re on your way. Take care and see you soon!",
            "Certainly! Have a pleasant journey to your location. Goodbye for now!"
        )


        val furtlerandomIndex = Random.nextInt(furtleutr.size)
        val furtlerandomutr = furtleutr[furtlerandomIndex]

        // Say the selected response
        furhat.say(furtlerandomutr)

        goto(PartTwo)
    }
    onNoResponse {
        if (GlobalState.hinteractionCount>2){
            goto(PartTwo)
        }
        reentry()
    }
    onResponse(){
        furhat.say("I am sorry! I didn't understand you!")
        if(GlobalState.hinteractionCount>2){
            goto(PartTwo)
        }
        reentry()
    }
}


val BookInfo: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++


        val startIndex = entitiesString.indexOf('=') + 1
        var bookName = entitiesString.substring(startIndex).trim()
        if (bookName.endsWith("}")) {
            bookName = bookName.removeSuffix("}")
        }

        var Bname = bookName
        println(Bname)


        val booksFromDatabase: MutableList<String> = mutableListOf()
        val resultSetBookNames = DatabaseConnection.executeQuery("SELECT DISTINCT Bname FROM BOOKS")
        if (resultSetBookNames != null) {
            while (resultSetBookNames.next()) {
                val dbBook = resultSetBookNames.getString("Bname")
                booksFromDatabase.add(dbBook)
            }
        }


        var maxSimilarity = 0.0
        var mostSimilarBook = Bname
        for (dbBook in booksFromDatabase) {
            val similarity = computeLevenshteinSimilarity(Bname, dbBook)
            println("Similarity between '$Bname' and '$dbBook': $similarity")
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                mostSimilarBook = dbBook
            }
        }


        val similarityThreshold = 0.7


        if (maxSimilarity >= similarityThreshold) {
            Bname = mostSimilarBook
            bookName = Bname
        }


        val query = "SELECT author, description FROM books WHERE Bname = '$bookName'"
        val resultSet = DatabaseConnection.executeQuery(query)
        var author: String? = null
        var description: String? = null

        if (resultSet != null && resultSet.next()) {
            author = resultSet.getString("author")
            description = resultSet.getString("description")
        }

        if (author != null && description != null) {
            val libiutr = listOf("The book '$bookName' is authored by $author. Here is a brief description: $description",
                "Authored by $author, the book '$bookName' has the following description: $description.",
                "'$bookName' is written by $author. A brief description: $description.",
                "The author of '$bookName' is $author. Here’s a short description: $description.",
                "The book '$bookName' by $author is summarized as follows: $description.",
                "$author wrote the book '$bookName'. Here’s a brief description: $description.",
                "Written by $author, '$bookName' comes with this description: $description.",
                "'$bookName', authored by $author, has this description: $description.",
                "The book titled '$bookName' is by $author. Brief description: $description.",
                "'$bookName' is a book by $author. Here’s a brief summary: $description.",
                "The book '$bookName' is written by $author. Here’s a quick description: $description.")
            val libirandomIndex = Random.nextInt(libiutr.size)
            val libirandomutr = libiutr[libirandomIndex]
            furhat.say(libirandomutr)
        } else {
            val linbiutr = listOf("Sorry, I couldn't find information for the book '$bookName'.",
                "Unfortunately, I couldn't find information for the book '$bookName'.",
                "Apologies, but I couldn't locate information for the book '$bookName'.",
                "Sorry, there is no information available for the book '$bookName'.",
                "Regrettably, I couldn't find any information regarding the book '$bookName'.",
                "I'm sorry, but information for the book '$bookName' could not be found.",
                "Unfortunately, I couldn't retrieve information for the book '$bookName'.",
                "Apologies, but I couldn't find any details for the book '$bookName'.",
                "Sadly, there is no information on record for the book '$bookName'.",
                "Sorry, I couldn't locate details for the book '$bookName'.",
                "Regretfully, information for the book '$bookName' is not available.")
            val linbirandomIndex = Random.nextInt(linbiutr.size)
            val linbirandomutr = linbiutr[linbirandomIndex]
            furhat.say(linbirandomutr)
        }


        goto(PartTwo)
    }
}

val BooksByLocationNumber: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++


        val startIndex = entitiesString.indexOf('=') + 1
        var locationNo = entitiesString.substring(startIndex).trim()
        if (locationNo.endsWith("}")) {
            locationNo = locationNo.removeSuffix("}")
        }


        val bookNames: MutableList<String> = mutableListOf()
        val query = "SELECT Bname FROM books WHERE location_no = '$locationNo' ORDER BY RAND() LIMIT 6;"
        val resultSet = DatabaseConnection.executeQuery(query)

        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("Bname")
                bookNames.add(title)
            }
            if (bookNames.isNotEmpty()) {
                val locbutr = listOf("Here are the books available in location number $locationNo: ${bookNames.joinToString(", ")}",
                "These are the books available at location number $locationNo: ${bookNames.joinToString(", ")}.",
                "You'll find the following books at location number $locationNo: ${bookNames.joinToString(", ")}.",
                "The books located at location number $locationNo are: ${bookNames.joinToString(", ")}.",
                "At location number $locationNo, you can find these books: ${bookNames.joinToString(", ")}.",
                "Available at location number $locationNo are these books: ${bookNames.joinToString(", ")}.",
                "Here is the list of books at location number $locationNo: ${bookNames.joinToString(", ")}.",
                "Books available at location number $locationNo include: ${bookNames.joinToString(", ")}.",
                "The following books are available in location number $locationNo: ${bookNames.joinToString(", ")}.",
                "You can find these books at location number $locationNo: ${bookNames.joinToString(", ")}.",
                "Listed at location number $locationNo are these books: ${bookNames.joinToString(", ")}.")
                val locbutrandomIndex = Random.nextInt(locbutr.size)
                val locbrandomutr = locbutr[locbutrandomIndex]
                furhat.say(locbrandomutr)

                goto(PartTwo)
            } else {
                val locnbutr = listOf("Sorry, we couldn't find any books in location number $locationNo.",
                    "Unfortunately, we couldn't find any books at location number $locationNo.",
                    "Apologies, but there are no books available at location number $locationNo.",
                    "Sorry, there are no books in location number $locationNo.",
                    "We regret to inform you that there are no books at location number $locationNo.",
                    "Unfortunately, no books were found in location number $locationNo.",
                    "Sorry, but there are no books located at number $locationNo.",
                    "We couldn't find any books at location number $locationNo.",
                    "Sadly, there are no books available at location number $locationNo.",
                    "Apologies, but location number $locationNo has no books.",
                    "Sorry, there aren't any books in location number $locationNo."
                    )
                val locnbutrandomIndex = Random.nextInt(locnbutr.size)
                val locnbrandomutr = locnbutr[locnbutrandomIndex]
                furhat.say(locnbrandomutr)

                goto(PartTwo)
            }
        } else {

            val errorResponse = "Sorry, there was an error fetching information from the database."
            furhat.say(errorResponse)

            goto(PartTwo)
        }
    }
}


val ListGenresState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++
        val ligenavutr = listOf(
            "Sure, here are the genres we have:",
            "Of course! Here's a list of the available genres:",
            "Absolutely! These are the genres you can find:",
            "Sure thing! Take a look at the available genres:",
            "No problem! Here are the genres currently available:",
            "I'd be happy to help. Here are the genres we have right now:",
            "Certainly! Here are the genres you can choose from:",
            "Alright! Here’s a list of what’s available:",
            "Here are the genres we have:"
        )
        val ligenavrandomIndex = Random.nextInt(ligenavutr.size)
        val ligenavrandomutr = ligenavutr[ligenavrandomIndex]
        furhat.say(ligenavrandomutr)



        val resultSet = DatabaseConnection.executeQuery("SELECT DISTINCT genre FROM BOOKS")


        val genres = mutableListOf<String>()


        while (resultSet != null && resultSet.next()) {
            val genre = resultSet.getString("genre")
            genres.add(genre)
        }


        genres.forEach { genre ->
            furhat.say(genre)

        }

        if (genres.isEmpty()) {
            val lingenavutr = listOf(
                "Currently, there are no genres available.",
                "At the moment, no genres are available.",
                "There are currently no genres to choose from.",
                "No genres are available right now.",
                "We're sorry, but there are no genres available at this time.",
                "Unfortunately, there are no genres available currently.",
                "Presently, there are no genres available.",
                "As of now, no genres are available.",
                "There are no genres available at the moment.",
                "Right now, there are no genres available.",
                "No genres are available at the present time."
            )
            val lingenavrandomIndex = Random.nextInt(lingenavutr.size)
            val lingenavrandomutr = ligenavutr[lingenavrandomIndex]
            furhat.say(lingenavrandomutr)
        }
        // End of interaction
        furhat.say("That is about all!")
        goto(PartTwo)
    }
}

val MostRenewedBooksGenre: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++


        val startIndex = entitiesString.indexOf('=') + 1
        var genre = entitiesString.substring(startIndex).trim()
        if (genre.endsWith("}")) {
            genre = genre.removeSuffix("}")
        }

        val bookNames: MutableList<String> = mutableListOf()
        val query = "SELECT Bname FROM books WHERE genre = '$genre' ORDER BY renewal_count DESC LIMIT 5"
        val resultSet = DatabaseConnection.executeQuery(query)

        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("Bname")
                bookNames.add(title)
            }
            if (bookNames.isNotEmpty()) {
                val lirenbgenutr = listOf(
                    "Here are some of the most renewed books in the $genre genre: ${bookNames.joinToString(", ")}",
                    "Check out some of the most popular books in the $genre genre: ${bookNames.joinToString(", ")}.",
                    "Here are a few highly acclaimed books in the $genre genre: ${bookNames.joinToString(", ")}.",
                    "These are some of the top-rated books in the $genre genre: ${bookNames.joinToString(", ")}.",
                    "Discover some of the most renowned books in the $genre genre: ${bookNames.joinToString(", ")}.",
                    "Explore some of the most sought-after books in the $genre genre: ${bookNames.joinToString(", ")}.",
                    "Presenting some of the most celebrated books in the $genre genre: ${bookNames.joinToString(", ")}.",
                    "Here are some of the most talked-about books in the $genre genre: ${bookNames.joinToString(", ")}.",
                    "Take a look at some of the most beloved books in the $genre genre: ${bookNames.joinToString(", ")}.",
                    "We have some of the most recommended books in the $genre genre: ${bookNames.joinToString(", ")}.",
                    "Here are a selection of the most distinguished books in the $genre genre: ${bookNames.joinToString(", ")}."
                )
                val lirenbgenrandomIndex = Random.nextInt(lirenbgenutr.size)
                val lirenbgenrandomutr = lirenbgenutr[lirenbgenrandomIndex]
                furhat.say(lirenbgenrandomutr)

                goto(PartTwo)
            } else {
                val linrenbgenutr = listOf(
                    "Unfortunately, we couldn't find any popular books in the $genre genre.",
                    "Apologies, but we don't have any top-rated books in the $genre genre at the moment.",
                    "Sorry, there are no highly acclaimed books available in the $genre genre right now.",
                    "We regret to inform you that there are no sought-after books in the $genre genre.",
                    "Unfortunately, there are no renowned books in the $genre genre at this time.",
                    "Apologies, but it looks like we don't have any well-known books in the $genre genre.",
                    "Sorry, we couldn't locate any celebrated books in the $genre genre.",
                    "We apologize, but there are no distinguished books in the $genre genre available.",
                    "Unfortunately, there are no noteworthy books in the $genre genre right now.",
                    "Regrettably, we couldn't find any acclaimed books in the $genre genre.",
                    )
                val linrenbgenrandomIndex = Random.nextInt(linrenbgenutr.size)
                val linrenbgenrandomutr = linrenbgenutr[linrenbgenrandomIndex]
                furhat.say(linrenbgenrandomutr)

                goto(PartTwo)
            }
        } else {
            val errorResponse = "Sorry, there was an error fetching information from the database."
            furhat.say(errorResponse)

            goto(PartTwo)
        }
    }
}

val MostRenewedBooksSubject: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++


        val startIndex = entitiesString.indexOf('=') + 1
        var subject = entitiesString.substring(startIndex).trim()
        if (subject.endsWith("}")) {
            subject = subject.removeSuffix("}")
        }


        val bookNames: MutableList<String> = mutableListOf()
        val query = "SELECT Bname FROM books WHERE subject = '$subject' ORDER BY renewal_count DESC LIMIT 5"
        val resultSet = DatabaseConnection.executeQuery(query)

        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("Bname")
                bookNames.add(title)
            }
            if (bookNames.isNotEmpty()) {
                val lirenbsubutr = listOf(
                    "Here are some of the most renewed books in the $subject subject: ${bookNames.joinToString(", ")}",
                    "Check out some of the most popular books in the $subject subject: ${bookNames.joinToString(", ")}.",
                    "Here are a few highly acclaimed books in the $subject subject: ${bookNames.joinToString(", ")}.",
                    "These are some of the top-rated books in the $subject subject: ${bookNames.joinToString(", ")}.",
                    "Discover some of the most renowned books in the $subject: ${bookNames.joinToString(", ")}.",
                    "Explore some of the most sought-after books in the $subject subject: ${bookNames.joinToString(", ")}.",
                    "Presenting some of the most celebrated books in the $subject subject: ${bookNames.joinToString(", ")}.",
                    "Here are some of the most talked-about books in the $subject: ${bookNames.joinToString(", ")}.",
                    "Take a look at some of the most beloved books in the $subject: ${bookNames.joinToString(", ")}.",
                    "We have some of the most recommended books in the $subject: ${bookNames.joinToString(", ")}.",
                    "Here are a selection of the most distinguished books in the $subject: ${bookNames.joinToString(", ")}."
                )
                val lirenbsubrandomIndex = Random.nextInt(lirenbsubutr.size)
                val lirenbsubrandomutr = lirenbsubutr[lirenbsubrandomIndex]
                furhat.say(lirenbsubrandomutr)

                goto(PartTwo)
            } else {
                val linrenbsubutr = listOf(
                    "Unfortunately, we couldn't find any popular books in the $subject subject.",
                    "Apologies, but we don't have any top-rated books in the $subject subject at the moment.",
                    "Sorry, there are no highly acclaimed books available in the $subject subject right now.",
                    "We regret to inform you that there are no sought-after books in the $subject subject.",
                    "Unfortunately, there are no renowned books in $subject at this time.",
                    "Apologies, but it looks like we don't have any well-known books in the $subject subject.",
                    "Sorry, we couldn't locate any celebrated books in $subject subject.",
                    "We apologize, but there are no distinguished books in the $subject subject available.",
                    "Unfortunately, there are no noteworthy books in the $subject subject right now.",
                    "Regrettably, we couldn't find any acclaimed books in the $subject subject.",
                )
                val linrenbsubrandomIndex = Random.nextInt(linrenbsubutr.size)
                val linrenbsubrandomutr = linrenbsubutr[linrenbsubrandomIndex]
                furhat.say(linrenbsubrandomutr)

                goto(PartTwo)
            }
        } else {
            val errorResponse = "Sorry, there was an error fetching information from the database."
            furhat.say(errorResponse)

            goto(PartTwo) // Adjust as per your flow
        }
    }
}

val MostRenewedBooksAuthor: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val startIndex = entitiesString.indexOf('=') + 1
        var author = entitiesString.substring(startIndex).trim()
        if (author.endsWith("}")) {
            author = author.removeSuffix("}")
        }


        val authorsFromDatabase: MutableList<String> = mutableListOf()
        val resultSetAuthors = DatabaseConnection.executeQuery("SELECT DISTINCT author FROM BOOKS")
        if (resultSetAuthors != null) {
            while (resultSetAuthors.next()) {
                val dbAuthor = resultSetAuthors.getString("author")
                authorsFromDatabase.add(dbAuthor)
            }
        }


        var maxSimilarity = 0.0
        var mostSimilarAuthor = author
        for (dbAuthor in authorsFromDatabase) {
            val similarity = computeLevenshteinSimilarity(author, dbAuthor)
//            println("Similarity between '$author' and '$dbAuthor': $similarity")
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                mostSimilarAuthor = dbAuthor
            }
        }


        val similarityThreshold = 0.55


        if (maxSimilarity >= similarityThreshold) {
            author = mostSimilarAuthor
        }

        val bookNames: MutableList<String> = mutableListOf()
        val query = "SELECT Bname FROM books WHERE author = '$author' ORDER BY renewal_count DESC LIMIT 5"
        val resultSet = DatabaseConnection.executeQuery(query)

        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("Bname")
                bookNames.add(title)
            }
            if (bookNames.isNotEmpty()) {
                val lirenbauthutr = listOf(
                    "Here are some of the most renewed books by $author: ${bookNames.joinToString(", ")}",
                    "Check out some of the most popular books by $author: ${bookNames.joinToString(", ")}.",
                    "Here are a few highly acclaimed books by $author: ${bookNames.joinToString(", ")}.",
                    "These are some of the top-rated books by $author: ${bookNames.joinToString(", ")}.",
                    "Discover some of the most renowned books by $author: ${bookNames.joinToString(", ")}.",
                    "Explore some of the most sought-after books by $author: ${bookNames.joinToString(", ")}.",
                    "Presenting some of the most celebrated books by $author: ${bookNames.joinToString(", ")}.",
                    "Here are some of the most talked-about books by $author: ${bookNames.joinToString(", ")}.",
                    "Take a look at some of the most beloved books by $author: ${bookNames.joinToString(", ")}.",
                    "We have some of the most recommended books by $author: ${bookNames.joinToString(", ")}.",
                    "Here are a selection of the most distinguished books by $author: ${bookNames.joinToString(", ")}."
                )
                val lirenbauthrandomIndex = Random.nextInt(lirenbauthutr.size)
                val lirenbauthrandomutr = lirenbauthutr[lirenbauthrandomIndex]
                furhat.say(lirenbauthrandomutr)

                goto(PartTwo)
            } else {
                val linrenbauthutr = listOf(
                    "Sorry, we couldn't find any renewed books by $author.",
                    "Unfortunately, we couldn't find any popular books by $author.",
                    "Apologies, but we don't have any top-rated books by $author at the moment.",
                    "Sorry, there are no highly acclaimed books by $author available right now.",
                    "We regret to inform you that there are no sought-after books by $author.",
                    "Unfortunately, there are no renowned books by $author at this time.",
                    "Apologies, but it looks like we don't have any well-known books by $author.",
                    "Sorry, we couldn't locate any celebrated books by $author.",
                    "We apologize, but there are no distinguished books by $author available.",
                    "Unfortunately, there are no noteworthy books by $author right now.",
                    "Regrettably, we couldn't find any acclaimed books by $author."
                )
                val linrenbauthrandomIndex = Random.nextInt(linrenbauthutr.size)
                val linrenbauthrandomutr = linrenbauthutr[linrenbauthrandomIndex]
                furhat.say(linrenbauthrandomutr)

                goto(PartTwo)
            }
        } else {

            val errorResponse = "Sorry, there was an error fetching information from the database."
            furhat.say(errorResponse)

            goto(PartTwo)
        }
    }
}

val MostRenewedBooksKeyword: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++


        val startIndex = entitiesString.indexOf('=') + 1
        var keywords = entitiesString.substring(startIndex).trim()
        if (keywords.endsWith("}")) {
            keywords = keywords.removeSuffix("}")
        }


        val bookNames: MutableList<String> = mutableListOf()
        val query = "SELECT Bname FROM books WHERE keywords LIKE '%$keywords%' ORDER BY renewal_count DESC LIMIT 5"
        val resultSet = DatabaseConnection.executeQuery(query)

        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("Bname")
                bookNames.add(title)
            }
            if (bookNames.isNotEmpty()) {
                val lirenbkeyutr = listOf(
                    "Here are some of the most renewed books with keywords $keywords: ${bookNames.joinToString(", ")}",
                    "Check out some of the most popular books with the keywords $keywords: ${bookNames.joinToString(", ")}.",
                    "Here are a few highly acclaimed books featuring the keywords $keywords: ${bookNames.joinToString(", ")}.",
                    "These are some of the top-rated books with keywords $keywords: ${bookNames.joinToString(", ")}.",
                    "Discover some of the most renowned books that include the keywords $keywords: ${bookNames.joinToString(", ")}.",
                    "Explore some of the most sought-after books with the keywords $keywords: ${bookNames.joinToString(", ")}.",
                    "Presenting some of the most celebrated books with keywords $keywords: ${bookNames.joinToString(", ")}.",
                    "Here are some of the most talked-about books featuring the keywords $keywords: ${bookNames.joinToString(", ")}.",
                    "Take a look at some of the most beloved books with keywords $keywords: ${bookNames.joinToString(", ")}.",
                    "We have some of the most recommended books that include the keywords $keywords: ${bookNames.joinToString(", ")}.",
                    "Here are a selection of the most distinguished books with keywords $keywords: ${bookNames.joinToString(", ")}."

                )
                val lirenbkeyrandomIndex = Random.nextInt(lirenbkeyutr.size)
                val lirenbkeyrandomutr = lirenbkeyutr[lirenbkeyrandomIndex]
                furhat.say(lirenbkeyrandomutr)

                goto(PartTwo)
            } else {
                val linrenbkeyutr = listOf(
                    "Sorry, we couldn't find any renewed books with keywords $keywords.",
                    "Unfortunately, we couldn't find any popular books with the keywords $keywords.",
                    "Apologies, but we don't have any top-rated books featuring the keywords $keywords at the moment.",
                    "Sorry, there are no highly acclaimed books with the keywords $keywords available right now.",
                    "We regret to inform you that there are no sought-after books with the keywords $keywords.",
                    "Unfortunately, there are no renowned books with the keywords $keywords at this time.",
                    "Apologies, but it looks like we don't have any well-known books featuring the keywords $keywords.",
                    "Sorry, we couldn't locate any celebrated books with the keywords $keywords.",
                    "We apologize, but there are no distinguished books with the keywords $keywords available.",
                    "Unfortunately, there are no noteworthy books with the keywords $keywords right now.",
                    "Regrettably, we couldn't find any acclaimed books with the keywords $keywords."

                )
                val linrenbkeyrandomIndex = Random.nextInt(linrenbkeyutr.size)
                val linrenbkeyrandomutr = linrenbkeyutr[linrenbkeyrandomIndex]
                furhat.say(linrenbkeyrandomutr)

                goto(PartTwo)
            }
        } else {

            val errorResponse = "Sorry, there was an error fetching information from the database."
            furhat.say(errorResponse)

            goto(PartTwo)
        }
    }
}

val ListAuthorsState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++
        val liauthavutr = listOf(
            "Sure, here are the authors we have:",
            "Of course! Here's a list of the available authors:",
            "Absolutely! These are the authors you can find:",
            "Sure thing! Take a look at the available authors:",
            "No problem! Here are the authors currently available:",
            "I'd be happy to help. Here are the authors we have right now:",
            "Certainly! Here are the authors you can choose from:",
            "Alright! Here’s a list of what’s available:",
            "Here are the authors we have:"
        )
        val liauthavrandomIndex = Random.nextInt(liauthavutr.size)
        val liauthavrandomutr = liauthavutr[liauthavrandomIndex]
        furhat.say(liauthavrandomutr)



        val query = "SELECT DISTINCT author FROM BOOKS ORDER BY RAND() LIMIT 6"
        val resultSet = DatabaseConnection.executeQuery(query)


        val authors = mutableListOf<String>()


        while (resultSet != null && resultSet.next()) {
            val author = resultSet.getString("author")
            authors.add(author)
        }


        val authorsList = authors.joinToString(", ")

        if (authors.isNotEmpty()) {

            furhat.say("The available authors are $authorsList.")
        } else {
            furhat.say("Currently, there are no authors available.")
        }


        furhat.say("That is about all!")
        goto(PartTwo)
    }
}

val ListSubjectsState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++
        val lisubavutr = listOf(
            "Sure, here are the subjects we have:",
            "Of course! Here's a list of the available subjects:",
            "Absolutely! These are the subjects you can find:",
            "Sure thing! Take a look at the available subjects:",
            "No problem! Here are the subjects currently available:",
            "I'd be happy to help. Here are the subjects we have right now:",
            "Certainly! Here are the subjects you can choose from:",
            "Alright! Here’s a list of what’s available:",
            "Here are the subjects we have:"
        )
        val lisubavrandomIndex = Random.nextInt(lisubavutr.size)
        val lisubavrandomutr = lisubavutr[lisubavrandomIndex]
        furhat.say(lisubavrandomutr)


        val query = "SELECT DISTINCT subject FROM BOOKS ORDER BY RAND() LIMIT 6"
        val resultSet = DatabaseConnection.executeQuery(query)


        val subjects = mutableListOf<String>()


        while (resultSet != null && resultSet.next()) {
            val subject = resultSet.getString("subject")
            subjects.add(subject)
        }


        val subjectsList = subjects.joinToString(", ")

        if (subjects.isNotEmpty()) {
            furhat.say("The available subjects are $subjectsList.")
        } else {
            furhat.say("Currently, there are no subjects available.")
        }


        furhat.say("These are the subjects we currently have.")
        goto(PartTwo)
    }
}

val BGenre: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++
        val startIndex = entitiesString.indexOf('=') + 1
        var extractedString = entitiesString.substring(startIndex).trim()
        if (extractedString.endsWith("}")) {
            extractedString = extractedString.removeSuffix("}")
        }
        val genre = extractedString
        val bookNames: MutableList<String> = mutableListOf()
        val resultSet = DatabaseConnection.executeQuery("SELECT Bname FROM BOOKS WHERE genre = '$genre' ORDER BY RAND() LIMIT 6")
        if (resultSet != null) {
            while (resultSet.next()) {
                val Bname = resultSet.getString("Bname")
                bookNames.add(Bname)
            }
            if (bookNames.isNotEmpty()) {
                val booksString = bookNames.joinToString(", ")
                val bgenutr = listOf("Here are the books in $genre:", "The following books belong to $genre:", "Listed below are the books in $genre:",
                    "These books are categorized under $genre:", "The $genre includes the following books:", "In $genre, you will find the following books:",
                    "The $genre features these books:", "Books in this $genre are as follows:", "The $genre consists of these books:", "This genre encompasses the following books:",
                    "Included in $genre are the books:", "You will find these books in the $genre genre:", "Books belonging to this genre include:", "The books classified in this genre are:",
                    "Under this genre, the books are:")
                val bgenrandomIndex = Random.nextInt(bgenutr.size)
                val bgenrandomutr = bgenutr[bgenrandomIndex]
                furhat.say(bgenrandomutr)
                furhat.say(booksString)

                goto(PartTwo)
            } else {
                val bnotgenutr = listOf("No books are available in $genre.", "$genre currently has no books.",
                    "There aren't any books in $genre genre.", "No books can be found in $genre.", "$genre does not include any books.", "There are no books listed under $genre.",
                    "We have no books in $genre.", "Unfortunately, $genre has no books.", "There are no available books in $genre.", "$genre has no books at the moment.",
                    "You won't find any books in $genre.", "There are zero books in $genre", "$genre is empty of books.", "Currently, there are no books in $genre.",
                    "No books fall under this genre.")
                val bnotgenrandomIndex = Random.nextInt(bnotgenutr.size)
                val bnotgenrandomutr = bnotgenutr[bnotgenrandomIndex]
                furhat.say(bnotgenrandomutr)

                goto(PartTwo)
            }
            }
        }
    }

val BAuthor: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++
        val startIndex = entitiesString.indexOf('=') + 1
        var extractedString = entitiesString.substring(startIndex).trim()
        if (extractedString.endsWith("}")) {
            extractedString = extractedString.removeSuffix("}")
        }
        var author = extractedString

        val authorsFromDatabase: MutableList<String> = mutableListOf()
        val resultSetAuthors = DatabaseConnection.executeQuery("SELECT DISTINCT author FROM BOOKS")
        if (resultSetAuthors != null) {
            while (resultSetAuthors.next()) {
                val dbAuthor = resultSetAuthors.getString("author")
                authorsFromDatabase.add(dbAuthor)
            }
        }


        var maxSimilarity = 0.0
        var mostSimilarAuthor = author
        for (dbAuthor in authorsFromDatabase) {
            val similarity = computeLevenshteinSimilarity(author, dbAuthor)
//            println("Similarity between '$author' and '$dbAuthor': $similarity")
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                mostSimilarAuthor = dbAuthor
            }
        }


        val similarityThreshold = 0.55


        if (maxSimilarity >= similarityThreshold) {
            author = mostSimilarAuthor
        }

        val bookNames: MutableList<String> = mutableListOf()
        val resultSet = DatabaseConnection.executeQuery("SELECT Bname FROM BOOKS WHERE author = '$author' ORDER BY RAND() LIMIT 6")
        if (resultSet != null) {
            while (resultSet.next()) {
                val Bname = resultSet.getString("Bname")
                bookNames.add(Bname)
            }
            if (bookNames.isNotEmpty()) {
                val booksString = bookNames.joinToString(", ")
                val bauthutr = listOf(
                    "Here are the books by $author:", "The following books were written by $author:", "Listed below are the books authored by $author:", "These books are authored by $author:",
                    "We have the following books by $author in our library:", "In our library, you will find the following books by $author:",
                    "Our collection includes these books by $author:", "Books by this author are as follows:", "The works of $author include the following books:",
                    "$author has written the following books:", "You will find these books by $author in our library:", "Books belonging to $author include:",
                    "The books penned by $author are:", "Under this author's name, we have the following books:", "Our library features the following books by $author:",
                    "Included in our collection are books by $author:", "These are the books by this author that we have:", "We have listed the books by $author as follows:",
                    "The library's collection of $author's books includes:", "Books by $author available in our library are:"
                )
                val bauthrandomIndex = Random.nextInt(bauthutr.size)
                val bauthrandomutr = bauthutr[bauthrandomIndex]
                furhat.say(bauthrandomutr)
                furhat.say(booksString)

                goto(PartTwo)
            } else {
                val bnotauthutr = listOf("There are no books by $author in our library.", "We currently do not have any books by $author.",
                    "This author has no books available in our collection.", "Our library does not feature any books by $author.",
                    "Unfortunately, we don't have any books by this author at the moment.", "No books by $author are available right now.",
                    "We don't have any books written by $author.", "This author's books are not in our library.", "There are no available works by $author.",
                    "Our collection doesn't include any books by $author.", "We have no books by $author in stock.", "At present, there are no books by $author.",
                    "Books by $author are currently unavailable.", "We regret to inform you that we don't have books by $author.",
                    "$author is not represented in our library at this time.", "No works by $author can be found in our library.", "Our library lacks any books by $author.",
                    "There are no titles by $author in our collection.", "Sadly, we have no books by $author available.", "We do not have any books by $author in our database.")
                val bnotauthrandomIndex = Random.nextInt(bnotauthutr.size)
                val bnotauthrandomutr = bnotauthutr[bnotauthrandomIndex]
                furhat.say(bnotauthrandomutr)

                goto(PartTwo)
            }

        }
    }
}

val BSubject: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++
        val startIndex = entitiesString.indexOf('=') + 1
        var extractedString = entitiesString.substring(startIndex).trim()
        if (extractedString.endsWith("}")) {
            extractedString = extractedString.removeSuffix("}")
        }
        val subject = extractedString
        val bookNames: MutableList<String> = mutableListOf()
        val resultSet = DatabaseConnection.executeQuery("SELECT Bname FROM BOOKS WHERE subject = '$subject' ORDER BY RAND() LIMIT 6")
        if (resultSet != null) {
            while (resultSet.next()) {
                val Bname = resultSet.getString("Bname")
                bookNames.add(Bname)
            }
            if (bookNames.isNotEmpty()) {
                val booksString = bookNames.joinToString(", ")
                val bsubutr = listOf(
                    "Here are the books available under $subject:", "The following books cover this subject:", "Listed below are the books on $subject:",
                    "These books fall under the subject of $subject:", "Our library includes the following books on $subject:", "In this subject area, you will find the following books:",
                    "$subject includes these books:", "Books on this subject are as follows:", "$subject encompasses the following books:",
                    "Included in $subject are the books:", "You will find these books under $subject of:", "Books related to $subject include:",
                    "The books classified under this subject are:", "Under this subject, the books are:", "Our collection on $subject includes:",
                    "These are the books we have on $subject:", "We have listed the books on this subject as follows:", "The library's collection on $subject includes:",
                    "Books available on $subject in our library are:", "Our library features the following books on $subject:"
                )
                val bsubrandomIndex = Random.nextInt(bsubutr.size)
                val bsubrandomutr = bsubutr[bsubrandomIndex]
                furhat.say(bsubrandomutr)
                furhat.say(booksString)

                goto(PartTwo)
            } else {
                val bnotsubutr = listOf("There are no books available on $subject.", "We currently do not have any books on $subject.",
                    "$subject has no books available in our collection.", "Our library does not feature any books on $subject.",
                    "Unfortunately, we don't have any books on $subject at the moment.", "No books on $subject are available right now.",
                    "We don't have any books covering $subject.", "Books on $subject are not in our library.", "There are no available books on $subject.",
                    "Our collection doesn't include any books on $subject.", "We have no books on $subject in stock.", "At present, there are no books on $subject.",
                    "Books on $subject are currently unavailable.", "We regret to inform you that we don't have books on $subject.",
                    "$subject is not represented in our library at this time.", "No books on $subject can be found in our library.", "Our library lacks any books on $subject.",
                    "There are no titles on $subject in our collection.", "Sadly, we have no books on this subject available.",
                    "We do not have any books on t$subject in our database.")
                val bnotsubrandomIndex = Random.nextInt(bnotsubutr.size)
                val bnotsubrandomutr = bnotsubutr[bnotsubrandomIndex]
                furhat.say(bnotsubrandomutr)

                goto(PartTwo)
            }

        }
    }
}

val BookNameGenre: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++
        val startIndex = entitiesString.indexOf('=') + 1
        var bookTitle = entitiesString.substring(startIndex).trim()
        if (bookTitle.endsWith("}")) {
            bookTitle = bookTitle.removeSuffix("}")
        }

        var Bname = bookTitle
        println(Bname)

        val booksFromDatabase: MutableList<String> = mutableListOf()
        val resultSetBookNames = DatabaseConnection.executeQuery("SELECT DISTINCT Bname FROM BOOKS")
        if (resultSetBookNames != null) {
            while (resultSetBookNames.next()) {
                val dbBook = resultSetBookNames.getString("Bname")
                booksFromDatabase.add(dbBook)
            }
        }


        var maxSimilarity = 0.0
        var mostSimilarBook = Bname
        for (dbBook in booksFromDatabase) {
            val similarity = computeLevenshteinSimilarity(Bname, dbBook)
            println("Similarity between '$Bname' and '$dbBook': $similarity")
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                mostSimilarBook = dbBook
            }
        }

        val similarityThreshold = 0.7


        if (maxSimilarity >= similarityThreshold) {
            Bname = mostSimilarBook
            bookTitle = Bname
        }

        val query = "SELECT genre FROM books WHERE Bname = '$bookTitle'"
        val resultSet = DatabaseConnection.executeQuery(query)

        if (resultSet != null && resultSet.next()) {
            val genre = resultSet.getString("genre")
            val libogenutr = listOf(
                "The genre of the book '$bookTitle' is $genre.",
                "The book '$bookTitle' falls under the $genre genre.",
                "'$bookTitle' belongs to the $genre genre.",
                "The genre of '$bookTitle' is $genre.",
                "Classified as $genre, '$bookTitle' is a notable book.",
                "'$bookTitle' is categorized in the $genre genre.",
                "The genre for '$bookTitle' is $genre.",
                "'$bookTitle' is a prime example of the $genre genre.",
                "In the $genre genre, you'll find '$bookTitle'.",
                "'$bookTitle' fits within the $genre genre.",
                "The book '$bookTitle' is of the $genre genre."
            )
            val libogenrandomIndex = Random.nextInt(libogenutr.size)
            val libogenrandomutr = libogenutr[libogenrandomIndex]
            furhat.say(libogenrandomutr)

            goto(PartTwo)
        } else {
            val linbogenutr = listOf(
                "Sorry, I couldn't find the book titled '$bookTitle' in the library.",
                "Unfortunately, I couldn't locate the book titled '$bookTitle' in our library.",
                "Apologies, but the book titled '$bookTitle' isn't available in our library.",
                "Sorry, we don't have the book titled '$bookTitle' in our library.",
                "Regrettably, the book titled '$bookTitle' is not in our library collection.",
                "I'm sorry, but we couldn't find the book titled '$bookTitle' in our library.",
                "Sadly, the book titled '$bookTitle' is not available in our library.",
                "We apologize, but the book titled '$bookTitle' is not found in our library.",
                "Unfortunately, the book titled '$bookTitle' is missing from our library.",
                "Sorry, but the book titled '$bookTitle' doesn't appear to be in our library.",
                "I'm afraid we don't have the book titled '$bookTitle' in our library."
            )
            val linbogenrandomIndex = Random.nextInt(linbogenutr.size)
            val linbogenrandomutr = linbogenutr[linbogenrandomIndex]
            furhat.say(linbogenrandomutr)

            goto(PartTwo)
        }
    }
}

val TotalBooksCount: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val query = "SELECT COUNT(*) AS total FROM books"
        val resultSet = DatabaseConnection.executeQuery(query)

        if (resultSet != null && resultSet.next()) {
            val totalBooks = resultSet.getInt("total")
            val totalbookutr = listOf("The total number of books in the library is $totalBooks.",
                "The total number of books in the library is $totalBooks.",
                "In the library, there are $totalBooks books in total.",
                "Currently, the library houses $totalBooks books.",
                "There are $totalBooks books available in the library.",
                "At present, the library contains $totalBooks books.",
                "The library has a total of $totalBooks books.",
                "The number of books in the library amounts to $totalBooks.",
                "There are $totalBooks books stored in the library.",
                "The library's collection comprises $totalBooks books.",
                "We have $totalBooks books in our library.")
            val totalbooksrandomIndex = Random.nextInt(totalbookutr.size)
            val totalbooksrandomutr = totalbookutr[totalbooksrandomIndex]
            furhat.say(totalbooksrandomutr)

            goto(PartTwo)
        } else {
            val errorResponse = "Sorry, there was an error fetching the total number of books from the database."
            furhat.say(errorResponse)

            goto(PartTwo) // Adjust as per your flow
        }
    }
}

val BookNameSubject: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val startIndex = entitiesString.indexOf('=') + 1
        var bookTitle = entitiesString.substring(startIndex).trim()
        if (bookTitle.endsWith("}")) {
            bookTitle = bookTitle.removeSuffix("}")
        }
        var Bname = bookTitle
        println(Bname)

        val booksFromDatabase: MutableList<String> = mutableListOf()
        val resultSetBookNames = DatabaseConnection.executeQuery("SELECT DISTINCT Bname FROM BOOKS")
        if (resultSetBookNames != null) {
            while (resultSetBookNames.next()) {
                val dbBook = resultSetBookNames.getString("Bname")
                booksFromDatabase.add(dbBook)
            }
        }

        var maxSimilarity = 0.0
        var mostSimilarBook = Bname
        for (dbBook in booksFromDatabase) {
            val similarity = computeLevenshteinSimilarity(Bname, dbBook)
            println("Similarity between '$Bname' and '$dbBook': $similarity")
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                mostSimilarBook = dbBook
            }
        }

        val similarityThreshold = 0.7

        if (maxSimilarity >= similarityThreshold) {
            Bname = mostSimilarBook
            bookTitle = Bname
        }

        val query = "SELECT subject FROM books WHERE Bname = '$bookTitle'"
        val resultSet = DatabaseConnection.executeQuery(query)

        if (resultSet != null && resultSet.next()) {
            val subject = resultSet.getString("subject")
            val libosubutr = listOf(
                "The subject of the book '$bookTitle' is $subject.",
                "The book '$bookTitle' covers the subject of $subject.",
                "The topic of '$bookTitle' is $subject.",
                "'$bookTitle' is about $subject.",
                "The focus of '$bookTitle' is $subject.",
                "The main subject of '$bookTitle' is $subject.",
                "In '$bookTitle', the subject is $subject.",
                "'$bookTitle' delves into the subject of $subject.",
                "'$bookTitle' explores the subject of $subject.",
                "The book '$bookTitle' deals with the subject of $subject.",
                "'$bookTitle' primarily discusses $subject."

            )
            val libosubrandomIndex = Random.nextInt(libosubutr.size)
            val libosubrandomutr = libosubutr[libosubrandomIndex]
            furhat.say(libosubrandomutr)

            goto(PartTwo)

        } else {
            val linbosubutr = listOf(
                "Sorry, I couldn't find the book titled '$bookTitle' in the library.",
                "Unfortunately, I couldn't locate the book titled '$bookTitle' in our library.",
                "Apologies, but the book titled '$bookTitle' isn't available in our library.",
                "Sorry, we don't have the book titled '$bookTitle' in our library.",
                "Regrettably, the book titled '$bookTitle' is not in our library collection.",
                "I'm sorry, but we couldn't find the book titled '$bookTitle' in our library.",
                "Sadly, the book titled '$bookTitle' is not available in our library.",
                "We apologize, but the book titled '$bookTitle' is not found in our library.",
                "Unfortunately, the book titled '$bookTitle' is missing from our library.",
                "Sorry, but the book titled '$bookTitle' doesn't appear to be in our library.",
                "I'm afraid we don't have the book titled '$bookTitle' in our library."
            )
            val linbosubrandomIndex = Random.nextInt(linbosubutr.size)
            val linbosubrandomutr = linbosubutr[linbosubrandomIndex]
            furhat.say(linbosubrandomutr)
            goto(PartTwo)
        }
    }
}

val BKeyword: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++
        val startIndex = entitiesString.indexOf('=') + 1
        var extractedString = entitiesString.substring(startIndex).trim()
        if (extractedString.endsWith("}")) {
            extractedString = extractedString.removeSuffix("}")
        }
        val keyword = extractedString
        val bookNames: MutableList<String> = mutableListOf()
        val resultSet = DatabaseConnection.executeQuery("SELECT Bname FROM BOOKS WHERE keywords LIKE '$keyword' OR keywords LIKE '$keyword,%' OR keywords LIKE '%, " +
                "$keyword,%' OR keywords LIKE '%, $keyword' ORDER BY RAND() LIMIT 6")
        if (resultSet != null) {
            while (resultSet.next()) {
                val Bname = resultSet.getString("Bname")
                bookNames.add(Bname)
            }
            if (bookNames.isNotEmpty()) {
                val booksString = bookNames.joinToString(", ")
                val bkeyutr = listOf(
                    "Here are the books available for $keyword:","Here are the books tagged with $keyword:", "The following books match this keyword:",
                    "Listed are the books associated with $keyword:", "These books are categorized under $keyword:", "Our library includes the following books with this keyword:",
                    "In this keyword category, you will find the following books:", "The keyword includes these books:", "Books related to $keyword are as follows:",
                    "This keyword encompasses the following books:", "Included in $keyword are the books:", "You will find these books under $keyword:",
                    "Books matching $keyword include:", "The books classified under $keyword are:", "Under $keyword, the books are:",
                    "Our collection with $keyword includes:", "These are the books we have with this keyword:", "We have listed the books with this keyword as follows:",
                    "The library's collection with this keyword includes:", "Books available with this keyword in our library are:",
                    "Our library features the following books tagged with this keyword:"
                )
                val bkeyrandomIndex = Random.nextInt(bkeyutr.size)
                val bkeyrandomutr = bkeyutr[bkeyrandomIndex]
                furhat.say(bkeyrandomutr)
                furhat.say(booksString)
                goto(PartTwo)
            } else {
                val bnotkeyutr = listOf("There are no books available with $keyword.", "We currently do not have any books with $keyword.",
                    "No books are associated with this keyword $keyword in our collection.", "Our library does not feature any $keyword books.",
                    "Unfortunately, we don't have any $keyword books at the moment.", "No books with this keyword $keyword are available right now.",
                    "We don't have any books matching this keyword.", "Books with this keyword are not in our library.", "There are no available $keyword books.",
                    "Our collection doesn't include any $keyword books.", "We have no books with this keyword in stock.", "At present, there are no books with this keyword.",
                    "Books with this keyword $keyword are currently unavailable.", "We regret to inform you that we don't have $keyword books.",
                    "$keyword is not represented in our library at this time.", "No books with this keyword can be found in our library.",
                    "Our library lacks any $keyword books.", "There are no titles with this keyword in our collection.", "Sadly, we have no $keyword books.",
                    "We do not have any books with this keyword in our library.")
                val bnotkeyrandomIndex = Random.nextInt(bnotkeyutr.size)
                val bnotkeyrandomutr = bnotkeyutr[bnotkeyrandomIndex]
                furhat.say(bnotkeyrandomutr)
                goto(PartTwo)
            }

        }
    }
}

val BSimilarity: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++
        val startIndex = entitiesString.indexOf('=') + 1
        var extractedString = entitiesString.substring(startIndex).trim()
        if (extractedString.endsWith("}")) {
            extractedString = extractedString.removeSuffix("}")
        }
        var Btitle = extractedString

        var SBname = Btitle
        println(SBname)

        val booksFromDatabase: MutableList<String> = mutableListOf()
        val resultSetBookNames = DatabaseConnection.executeQuery("SELECT DISTINCT Bname FROM BOOKS")
        if (resultSetBookNames != null) {
            while (resultSetBookNames.next()) {
                val dbBook = resultSetBookNames.getString("Bname")
                booksFromDatabase.add(dbBook)
            }
        }

        var maxSimilarity = 0.0
        var mostSimilarBook = SBname
        for (dbBook in booksFromDatabase) {
            val similarity = computeLevenshteinSimilarity(SBname, dbBook)
            println("Similarity between '$SBname' and '$dbBook': $similarity")
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                mostSimilarBook = dbBook
            }
        }


        val similarityThreshold = 0.7

        if (maxSimilarity >= similarityThreshold) {
            SBname = mostSimilarBook
            Btitle = SBname
        }

        val bookNames: MutableList<String> = mutableListOf()
        val query = """
            -- Extract keywords from the selected book
            WITH ExtractedBookKeywords AS (
                SELECT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(b1.keywords, ',', numbers.n), ',', -1)) AS keyword
                FROM (SELECT 1 n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
                      UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8
                      UNION ALL SELECT 9 UNION ALL SELECT 10) numbers
                INNER JOIN BOOKS b1
                ON CHAR_LENGTH(b1.keywords) - CHAR_LENGTH(REPLACE(b1.keywords, ',', '')) >= numbers.n - 1
                WHERE b1.Bname = '$Btitle'
            ),
            
            -- Extract keywords from all books
            AllBookKeywords AS (
                SELECT b2.Bname, 
                       TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(b2.keywords, ',', numbers.n), ',', -1)) AS keyword
                FROM (SELECT 1 n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
                      UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8
                      UNION ALL SELECT 9 UNION ALL SELECT 10) numbers
                INNER JOIN BOOKS b2
                ON CHAR_LENGTH(b2.keywords) - CHAR_LENGTH(REPLACE(b2.keywords, ',', '')) >= numbers.n - 1
            )
            
            -- Find matching books
            SELECT DISTINCT abk.Bname
            FROM ExtractedBookKeywords gk
            INNER JOIN AllBookKeywords abk
            ON gk.keyword = abk.keyword
            WHERE abk.Bname != '$Btitle'
            ORDER BY RAND()
            LIMIT 6;
        """.trimIndent()

        val resultSet = DatabaseConnection.executeQuery(query)
        if (resultSet != null) {
            while (resultSet.next()) {
                val Bname = resultSet.getString("Bname")
                bookNames.add(Bname)
            }
            if (bookNames.isNotEmpty()) {
                val booksString = bookNames.joinToString(", ")
                val bsimutr = listOf("Here are some books similar to the given book:", "The following books are similar to the given book:",
                    "Listed are books that are similar to $Btitle:", "These books are similar to the given book:", "Our library includes the following books that are similar to:",
                    "Books similar to the given book include:", "The given book has similar titles, such as:", "This book has similar counterparts like:",
                    "Included in this list are books similar to $Btitle:", "You will find these books to be similar to $Btitle:", "Books resembling the given book include:",
                    "The books that share similarities with the given book are:", "Books that are akin to the given book are:", "Our collection features similar books to $Btitle:",
                    "These are books we have that are similar to the given book:", "We have listed books similar to the given book as follows:",
                    "The library's collection of books similar to $Btitle includes:", "Books available that are similar to the given book are:",
                    "Our library features the following similar books:")
                val bsimrandomIndex = Random.nextInt(bsimutr.size)
                val bsimrandomutr = bsimutr[bsimrandomIndex]
                furhat.say(bsimrandomutr)
                furhat.say(booksString)
                goto(PartTwo)
            } else {
                val bnotsimutr = listOf("We could not find any books similar to the given book.", "There are no books that we identified as similar to this one.",
                    "Our search did not return any similar books.", "Unfortunately, we couldn't find books similar to the given book.", "No books were found that are similar to $Btitle",
                    "We currently could not find any similar books to $Btitle in our collection.", "$Btitle does not have any identified similar titles.",
                    "We were unable to locate any books resembling the given book.", "There are no similar books available in our library.",
                    "Our library does not feature any books similar to $Btitle", "No similar books are available at the moment.",
                    "We regret to inform you that there are no books like $Btitle.", "Similar books are not available in our catalog.",
                    "Our collection lacks any books similar to the given book.", "We have no similar titles to $Btitle in our database.",
                    "No books matching $Btitle's criteria could be found.", "Our search for similar books was unsuccessful.", "We did not identify any similar books in our inventory.",
                    "Sadly, we couldn't find books that are similar to the given book.", "No counterparts for $Btitle book were found in our collection.")
                val bnotsimrandomIndex = Random.nextInt(bnotsimutr.size)
                val bnotsimrandomutr = bnotsimutr[bnotsimrandomIndex]
                furhat.say(bnotsimrandomutr)
                goto(PartTwo)
            }

        }
    }
}


val FServices: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val fservutr = listOf("Want to know which book is available and where? Perhaps you wish to know about our Upcoming events?" +
            "If you wish to know about the Library Policies or any other Membership services. I am the one to ask" +
            " Perhaps you just want to chat", "If you need information about our library services, membership policies, or " +
            "borrowing limits, I'm here to help. Want to find out if a specific book is available and where to locate it? Or " +
            "maybe you're curious about the events happening right now? Feel free to ask, or we can just chat.",
            "Looking for details on library services or membership policies? Wondering about borrowing limits or checking if a " +
            "book is available and where it is? Perhaps you're interested in current events around the library? I'm here to provide " +
            "all the information you need. Or if you'd rather, we can simply have a chat.", "Whether you need to know about our library " +
            "services, membership rules, or borrowing limits, I can assist you. If you’re trying to find out if a certain book is available and where " +
            "it's located, or you’re interested in our latest events, I'm here. Or maybe you'd just like to chat for a while.",
            "Curious about our library services, membership policies, or borrowing limits? Need to check the availability and location of a book? " +
            "Interested in the current events we’re hosting? I'm here to answer all your questions. Or perhaps you'd like to chat instead.",
            "I can provide you with information on our library services, membership policies, and borrowing limits. If you're looking for a specific " +
            "book and want to know if it's available and where to find it, or you're curious about what's happening around the library, just let me know. " +
            "Or we can just have a casual chat.", "Do you want to know more about our library services, membership policies, or borrowing limits? " +
            "Are you searching for the availability and location of a specific book? Maybe you're interested in our current events? I'm here to help with " +
            "all that. Or if you prefer, we can just chat.", "I’m here to assist you with information on library services, membership policies, and borrowing " +
            "limits. If you need to find out if a particular book is available and where it’s located, or you're curious about our ongoing events, just ask. " +
            "Or if you feel like it, we can simply chat.", "Seeking details on library services, membership rules, or borrowing limits? Looking to find out " +
            "if a book is available and where to locate it? Interested in what's happening at the library right now? I can help with all of that. Or if you " +
            "just want to chat, that's fine too.", "I can help you discover what services our library offers, understand our membership policies, and learn " +
            "about borrowing limits. If you need to check the availability and location of a specific book or find out about current events, I'm here. " +
            "Or if you'd like, we can just have a chat.", "Need information on our library services, membership policies, or borrowing limits? Wondering " +
            "if a particular book is available and where it's located? Interested in the latest events happening here? I'm available to provide " +
            "all the details. Or we can simply chat if you prefer.")
        val fservrandomIndex = Random.nextInt(fservutr.size)
        val fservrandomutr = fservutr[fservrandomIndex]
        furhat.say(fservrandomutr)
        goto(PartTwo)
    }
}

val HQTF: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val hutr = listOf("I'm doing well, how about you?", "I'm fine, and you?", "I'm good, how are you?",
            "I'm great, what about you?", "I'm doing great, how are you?", "I'm feeling good, how about you?",
            "I'm well, and you?", "I'm okay, how are you doing?", "I'm feeling fine, what about you?",
            "I'm pretty good, how about yourself?" )
        val hrandomIndex = Random.nextInt(hutr.size)
        val hrandomutr = hutr[hrandomIndex]
        furhat.say(hrandomutr)
        goto(HTF)
    }
}

val HTF: State = state(Parent){
    onEntry {
        GlobalState.hinteractionCount++
        furhat.listen(timeout = 4000)
    }
    onResponse(HowGood()) {

        val goodutr = listOf(
            "That's great to hear! I'm glad you're doing well.",
            "Wonderful! It's always nice to hear that you're feeling good.",
            "Excellent! I'm happy that you're doing great.",
            "Fantastic! I'm pleased to hear that you're feeling so good.",
            "That's awesome! I'm glad you're feeling wonderful.",
            "I'm happy to hear that you're in high spirits!",
            "It's great to know that you're doing fantastic!",
            "I'm glad to hear that everything is going well for you."
        )
        val goodrandomIndex = Random.nextInt(goodutr.size)
        val goodrandomutr = goodutr[goodrandomIndex]
        furhat.say(goodrandomutr)
        goto(PartTwo)
    }
    onResponse(HowBad()) {
        val badutr = listOf(
            "I'm sorry to hear that. I hope things get better for you soon.",
            "That's unfortunate. I hope your day improves.",
            "I'm sorry you're not feeling well. Is there anything I can do to help?",
            "I understand. Sometimes we all have bad days.",
            "I'm here for you. Let me know if there's anything I can do.",
            "I'm sorry to hear you're having a rough day. I'm here if you need me.",
            "I hope things start looking up for you soon.",
            "It's tough to have bad days. Take care of yourself."
        )

        val badrandomIndex = Random.nextInt(badutr.size)
        val badrandomutr = badutr[badrandomIndex]
        furhat.say(badrandomutr)
        goto(PartTwo)
    }
    onResponse(HowMeh()) {
        val mehutr = listOf(
            "I see. It's okay to have average days.",
            "Thanks for letting me know. It's okay to feel neutral sometimes.",
            "I understand. Not every day can be special.",
            "That's alright. It's good to have balance.",
            "I hear you. Sometimes it's just a so-so kind of day.",
            "It's okay to feel indifferent sometimes.",
            "I get it. Just hanging in there is perfectly fine.",
            "It's alright to have days where you feel just okay."
        )

        val mehrandomIndex = Random.nextInt(mehutr.size)
        val mehrandomutr = mehutr[mehrandomIndex]

        furhat.say(mehrandomutr)
        goto(PartTwo)
    }
    onNoResponse {
        if (GlobalState.hinteractionCount>2){
            goto(PartTwo)
        }
        reentry()
    }
    onResponse(){
        furhat.say("I am sorry! I didn't understand you!")
        if(GlobalState.hinteractionCount>2){
            goto(PartTwo)
        }
        reentry()
    }
}

val HLocQUTF: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val travelutr = listOf(
            "Unfortunately, I can't travel anywhere! But I am happy to be here to help thee!",
            "Sorry, I'm not able to travel. But I'm here to assist you with anything you need!",
            "I can't go anywhere, but I'm always here to help you out!",
            "I may not be able to travel, but I'm right here to offer my assistance!"
        )
        val travelrandomIndex = Random.nextInt(travelutr.size)
        val travelrandomutr = travelutr[travelrandomIndex]
        furhat.say(travelrandomutr)
        goto(PartTwo)
    }
}

val FProj: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val fprojutr = listOf(
            "That's wonderful! I am glad to hear that! Projects are the most gratifying way to learn a subject.",
            "Fantastic! Working on projects is a great way to deepen your understanding.",
            "Excellent! Projects provide hands-on experience and help reinforce what you've learned.",
            "Great to hear! Engaging in projects is an effective method to apply your knowledge.",
            "Awesome! Projects not only enhance learning but also boost practical skills.",
            "That's great news! Projects are a fantastic way to put theory into practice.",
            "I'm glad to hear that! Projects can make the learning process more interactive and enjoyable.",
            "Wonderful! Projects are an excellent way to explore a subject in greater depth."
        )
        val fprojrandomIndex = Random.nextInt(fprojutr.size)
        val fprojrandomutr = fprojutr[fprojrandomIndex]
        furhat.say(fprojrandomutr)
        goto(PartTwo)
    }
}

val BWatch: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val bwatchutr = listOf("That's fantastic! While I can't watch movies, I understand their appeal.",
            "That's awesome! Even though I can't enjoy movies myself, I know they are valuable.",
            "That's wonderful! Although I can't view movies, I recognize their importance.",
            "That's great! Though I can't watch movies, I appreciate how much joy they bring.",
            "That's amazing! While I don't watch movies, I can see why people love them.",
            "That's cool! Even though I can't experience movies, I appreciate their impact.",
            "That's awesome! While movies aren't something I can enjoy, I know they mean a lot to people.",
            "That's fantastic! Though I don't watch movies, I understand their significance.",
            "That's terrific! While movies aren't part of my experience, I value their role in entertainment.",
            "That's wonderful! Although I can't watch movies, I appreciate their cultural importance.",
            "That's great! Even though movies aren't for me, I see their value.",
            "That's awesome! While I don't watch movies, I get why they're important.",
            "That's fantastic! Even though I can't enjoy movies, I know they have great value.",
            "That's cool! Although I can't watch movies, I understand their appeal.",
            "That's terrific! While movies aren't in my realm, I appreciate their significance.",
            "That's amazing! Though I don't watch movies, I know they bring a lot of joy.",
            "That's wonderful! While I can't experience movies, I understand their impact.",
            "That's fantastic! Even though movies aren't something I can watch, I recognize their value.",
            "That's great! Though I can't enjoy movies, I appreciate how they entertain others.",
            "That's amazing! While I'm not able to watch movies, I understand their importance.")
        val bwatchrandomIndex = Random.nextInt(bwatchutr.size)
        val bwatchrandomutr = bwatchutr[bwatchrandomIndex]
        furhat.say(bwatchrandomutr)
        goto(PartTwo)
    }
}

val HAsk: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++

        val hobbyutr = listOf(
            "That sounds exciting!",
            "What a great hobby!",
            "That's really cool!",
            "Impressive!",
            "Sounds like fun!",
            "That's awesome!",
            "How interesting!",
            "That's fantastic!",
            "Great to hear!",
            "Nice choice of hobby!",
            "That's wonderful!",
            "Way to go!",
            "Good for you!",
            "Sounds like a lot of fun!",
            "That's neat!",
            "You're really good at picking hobbies!",
            "That must be very rewarding!",
            "Cool hobby!",
            "Glad to hear you're enjoying it!",
            "That sounds like a lot of fun!"
        )
        val hobbyrandomIndex = Random.nextInt(hobbyutr.size)
        val hobbyrandomutr = hobbyutr[hobbyrandomIndex]
        furhat.say(hobbyrandomutr)
        goto(PartTwo)
    }
}

val CurrentTimeState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val currentDate = LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("MMMM dd, yyyy"))
        val currentTime = LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("hh:mm a"))
        val currentDay = LocalDate.now().dayOfWeek.toString().lowercase(Locale.getDefault())
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }

        val currdayutr = listOf(
            "Today is $currentDay, $currentDate. The current time is $currentTime.",
            "Today is $currentDay, $currentDate. The time now is $currentTime.",
            "It's $currentDay, $currentDate today. The current time is $currentTime.",
            "Today is $currentDay, $currentDate, and the time is $currentTime.",
            "The date today is $currentDay, $currentDate. The current time is $currentTime.",
            "On this $currentDay, $currentDate, the time is now $currentTime.",
            "It's $currentDay, $currentDate, and right now it's $currentTime.",
            "Today being $currentDay, $currentDate, the time is $currentTime.",
            "Currently, it's $currentDay, $currentDate, and the time is $currentTime.",
            "The current day and date is $currentDay, $currentDate, and the time is $currentTime.",
            "We are at $currentDay, $currentDate, and the current time is $currentTime."
        )

        val currdayrandomIndex = Random.nextInt(currdayutr.size)
        val currdayrandomutr = currdayutr[currdayrandomIndex]
        furhat.say(currdayrandomutr)

        goto(PartTwo)
    }
}


val AAsk: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++

        val currentYear = LocalDate.now().year
        val furhatCreationYear = 2011
        val furhatAge = currentYear - furhatCreationYear

        val ageutr = listOf("I am about $furhatAge years old, as my first prototype was created in $furhatCreationYear.",
            "Considering my first prototype was made in $furhatCreationYear, I am approximately $furhatAge years old.",
            "I am roughly $furhatAge years old, given that my initial prototype was built in $furhatCreationYear.",
            "My age is around $furhatAge years, since my first prototype came into existence in $furhatCreationYear.",
            "I am nearly $furhatAge years old, with my first prototype dating back to $furhatCreationYear.",
            "Since my first prototype was developed in $furhatCreationYear, I am around $furhatAge years old.",
            "I am close to $furhatAge years old, considering my first prototype was constructed in $furhatCreationYear.",
            "Taking into account that my first prototype was created in $furhatCreationYear, I am approximately $furhatAge years old.",
            "I am estimated to be $furhatAge years old, given that my first prototype was established in $furhatCreationYear.",
            "With my first prototype being made in $furhatCreationYear, I am about $furhatAge years old.",
            "I am approximately $furhatAge years old, considering my first prototype was created in $furhatCreationYear.")
        val agerandomIndex = Random.nextInt(ageutr.size)
        val agerandomutr = ageutr[agerandomIndex]
        furhat.say(agerandomutr)
        goto(PartTwo)
    }
}

val GAsk: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val genderutr = listOf(
            "I am genderless! I am whatever I can be.",
            "I don't have a gender. I can be whatever you need me to be!",
            "I am beyond gender! I exist to assist in any form.",
            "Gender doesn't apply to me! I am here to help you in any way I can.",
            "I am without gender! I am here to serve in any capacity.",
            "I don't conform to any gender! I am simply here to help.",
            "Gender is not something that defines me! I am whatever is needed.",
            "I am not bound by gender! I am here to assist you."
        )

        val genderrandomIndex = Random.nextInt(genderutr.size)
        val genderrandomutr = genderutr[genderrandomIndex]
        furhat.say(genderrandomutr)
        goto(PartTwo)
    }
}

val FAsk: State = state(Parent){
    onEntry {
        GlobalState.interactionCount++
        val funutr = listOf(
            "My idea of fun involves helping individuals such as yourself fulfill their needs!",
            "For me, fun is assisting people like you in achieving their goals!",
            "I find joy in helping individuals like you with whatever they need!",
            "My kind of fun is providing support and assistance to people like you!",
            "Helping you with your needs is what I consider fun!",
            "I enjoy making sure that your requirements are met to the best of my abilities!",
            "Assisting you in any way I can is my idea of a good time!",
            "I find it fun to help you accomplish your tasks and fulfill your needs!"
        )

        val funrandomIndex = Random.nextInt(funutr.size)
        val funrandomutr = funutr[funrandomIndex]

        furhat.say(funrandomutr)
        goto(PartTwo)
    }
}

val ListRecentBooksState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val recentbookslibutr = listOf(
            "Sure, here are the books that were recently added:",
            "Of course! Here's a list of the recently added books:",
            "Absolutely! These are the books you can find:",
            "Sure thing! Take a look at the recently added books:",
            "No problem! Here are the books that were recently added:",
            "I'd be happy to help. Here are the books we have added recently:",
            "Certainly! Here are the recently added books you can choose from:",
            "Alright! Here’s a list of the recently added books:",
            "Here are the recently added books:"
        )
        val recentbookslibrandomIndex = Random.nextInt(recentbookslibutr.size)
        val recentbookslibrandomutr = recentbookslibutr[recentbookslibrandomIndex]
        furhat.say(recentbookslibrandomutr)

        val query = "SELECT bname FROM BOOKS ORDER BY date_added DESC LIMIT 6"
        val resultSet = DatabaseConnection.executeQuery(query)

        val books = mutableListOf<String>()

        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("bname")
                books.add(title)
            }
            if (books.isNotEmpty()) {
                val recentbooks = books.joinToString(", ")
                furhat.say(recentbooks)
                goto(PartTwo)
            } else {
                furhat.say("Currently, there are no recently added books available.")
                goto(PartTwo)
            }
        } else {
            furhat.say("Sorry, there was an error fetching information from the database.")
            goto(PartTwo)
        }
    }
}

val ListRecentBooksByAuthorState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val recentbooksauthutr = listOf(
            "Sure, here are the books that were recently added by",
            "Of course! Here's a list of the recently added books by",
            "Absolutely! These are the books you can find by",
            "Sure thing! Take a look at the recently added books by",
            "No problem! Here are the books that were recently added by",
            "I'd be happy to help. Here are the books we have added recently by",
            "Certainly! Here are the recently added books you can choose from by",
            "Alright! Here’s a list of the recently added books by",
            "Here are the recently added books by"
        )
        val recentbooksauthrandomIndex = Random.nextInt(recentbooksauthutr.size)
        val recentbooksauthrandomutr = recentbooksauthutr[recentbooksauthrandomIndex]
        furhat.say(recentbooksauthrandomutr)
        var authorName = entitiesString.substringAfter('=').substringBefore('}').trim()

        val authorsFromDatabase: MutableList<String> = mutableListOf()
        val resultSetAuthors = DatabaseConnection.executeQuery("SELECT DISTINCT author FROM BOOKS")
        if (resultSetAuthors != null) {
            while (resultSetAuthors.next()) {
                val dbAuthor = resultSetAuthors.getString("author")
                authorsFromDatabase.add(dbAuthor)
            }
        }

        var maxSimilarity = 0.0
        var mostSimilarAuthor = authorName
        for (dbAuthor in authorsFromDatabase) {
            val similarity = computeLevenshteinSimilarity(authorName, dbAuthor)
//            println("Similarity between '$author' and '$dbAuthor': $similarity")
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                mostSimilarAuthor = dbAuthor
            }
        }


        val similarityThreshold = 0.55

        if (maxSimilarity >= similarityThreshold) {
            authorName = mostSimilarAuthor
        }

        val query = "SELECT bname FROM BOOKS WHERE author = '$authorName' ORDER BY date_added DESC LIMIT 6"
        val resultSet = DatabaseConnection.executeQuery(query)

        val books = mutableListOf<String>()
        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("bname")
                books.add(title)
            }
            if (books.isNotEmpty()) {
                val recentbooksauth = "$authorName: ${books.joinToString(", ")}"
                furhat.say(recentbooksauth)
                goto(PartTwo)
            } else {
                furhat.say("Currently, there are no recently added books available by $authorName.")
                goto(PartTwo)
            }
        } else {
            furhat.say("Sorry, there was an error fetching information from the database.")
            goto(PartTwo)
        }
    }
}

val ListRecentBooksByGenreState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val recentbooksgenutr = listOf(
            "Sure, here are the books that were recently added in this",
            "Of course! Here's a list of the recently added books in this",
            "Absolutely! These are the books you can find in this",
            "Sure thing! Take a look at the recently added books in this",
            "No problem! Here are the books that were recently added in this",
            "I'd be happy to help. Here are the books we have added recently in this",
            "Certainly! Here are the recently added books you can choose from in this",
            "Alright! Here’s a list of the recently added books in this",
            "Here are the recently added books in this"
        )
        val librecentbooksgenrandomIndex = Random.nextInt(recentbooksgenutr.size)
        val lirecentbooksgenrandomutr = recentbooksgenutr[librecentbooksgenrandomIndex]
        furhat.say(lirecentbooksgenrandomutr)

        val genre = entitiesString.substringAfter('=').substringBefore('}').trim()

        val query = "SELECT bname FROM BOOKS WHERE genre = '$genre' ORDER BY date_added DESC LIMIT 6"
        val resultSet = DatabaseConnection.executeQuery(query)

        val books = mutableListOf<String>()

        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("bname")
                books.add(title)
            }
            if (books.isNotEmpty()) {
                val recbooksgen = "$genre: ${books.joinToString(", ")}"
                furhat.say(recbooksgen)
                goto(PartTwo)
            } else {
                furhat.say("Currently, there are no recently added books available in the $genre genre.")
                goto(PartTwo)
            }
        } else {
            furhat.say("Sorry, there was an error fetching information from the database.")
            goto(PartTwo)
        }
    }
}

val ListRecentBooksBySubjectState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val lirecbooksubutr = listOf(
            "Sure, here are the books that were recently added in this subject:",
            "Of course! Here's a list of the recently added books in this subject:",
            "Absolutely! These are the books you can find in this subject:",
            "Sure thing! Take a look at the recently added books in this subject:",
            "No problem! Here are the books that were recently added in this subject:",
            "I'd be happy to help. Here are the books we have added recently in this subject:",
            "Certainly! Here are the recently added books you can choose from in this subject:",
            "Alright! Here’s a list of the recently added books in this subject:",
            "Here are the recently added books in this subject:"
        )
        val lirecbooksubrandomIndex = Random.nextInt(lirecbooksubutr.size)
        val lirecbooksubrandomutr = lirecbooksubutr[lirecbooksubrandomIndex]
        furhat.say(lirecbooksubrandomutr)

        val subject = entitiesString.substringAfter('=').substringBefore('}').trim()

        val query = "SELECT bname FROM BOOKS WHERE subject = '$subject' ORDER BY date_added DESC LIMIT 6"
        val resultSet = DatabaseConnection.executeQuery(query)

        val books = mutableListOf<String>()

        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("bname")
                books.add(title)
            }
            if (books.isNotEmpty()) {
                val recbookssub = "$subject: ${books.joinToString(", ")}"
                furhat.say(recbookssub)
                goto(PartTwo)
            } else {
                furhat.say("Currently, there are no recently added books available in the $subject subject.")
                goto(PartTwo)
            }
        } else {
            furhat.say("Sorry, there was an error fetching information from the database.")
            goto(PartTwo)
        }
    }
}

val ListRecentBooksByKeywordState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val reckeyutr = listOf(
            "Sure, here are the books that were recently added with this keyword:",
            "Of course! Here's a list of the recently added books with this keyword:",
            "Absolutely! These are the books you can find with this keyword:",
            "Sure thing! Take a look at the recently added books with this keyword:",
            "No problem! Here are the books that were recently added with this keyword:",
            "I'd be happy to help. Here are the books we have added recently with this keyword:",
            "Certainly! Here are the recently added books you can choose from with this keyword:",
            "Alright! Here’s a list of the recently added books with this keyword:",
            "Here are the recently added books with this keyword:"
        )
        val reckeyutrrandomIndex = Random.nextInt(reckeyutr.size)
        val reckeyrandomutr = reckeyutr[reckeyutrrandomIndex]
        furhat.say(reckeyrandomutr)

        val keyword = entitiesString.substringAfter('=').substringBefore('}').trim()

        println("Extracted keyword: $keyword")
        val query = "SELECT bname FROM BOOKS WHERE keywords LIKE '%$keyword%' ORDER BY date_added DESC LIMIT 6"

        println("Executing query: $query")

        val resultSet = DatabaseConnection.executeQuery(query)

        val books = mutableListOf<String>()

        if (resultSet != null) {
            while (resultSet.next()) {
                val title = resultSet.getString("bname")
                books.add(title)
            }
            if (books.isNotEmpty()) {
                val recentbookskey = "'$keyword': ${books.joinToString(", ")}"
                furhat.say(recentbookskey)
                goto(PartTwo)
            } else {
                furhat.say("Currently, there are no recently added books available with the keyword '$keyword'.")
                goto(PartTwo)
            }
        } else {
            furhat.say("Sorry, there was an error fetching information from the database.")
            goto(PartTwo)
        }
    }
}

val ListOngoingEventsState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val lionevutr = listOf(
            "Sure, here are the ongoing events:",
            "Of course! Here are the events happening right now:",
            "Absolutely! These are the ongoing events:",
            "Sure thing! Take a look at the events happening right now:",
            "No problem! Here are the events currently ongoing:",
            "I'd be happy to help. Here are the events happening at the moment:",
            "Certainly! Here are the ongoing events you can attend:",
            "Alright! Here’s a list of the events happening now:",
            "Here are the events currently ongoing:"
        )
        val lionevrandomIndex = Random.nextInt(lionevutr.size)
        val lionevrandomutr = lionevutr[lionevrandomIndex]
        furhat.say(lionevrandomutr)

        val currentDate = LocalDate.now().toString()
        val currentTime = LocalTime.now().toString().substring(0, 5) // HH:mm format

        val query = """
            SELECT event_name, start_time, end_time 
            FROM event 
            WHERE event_date = '$currentDate' 
            AND start_time <= '$currentTime' 
            AND end_time >= '$currentTime'
        """
        val resultSet = DatabaseConnection.executeQuery(query)

        val ongoingEvents = mutableListOf<String>()

        if (resultSet != null) {
            while (resultSet.next()) {
                val eventName = resultSet.getString("event_name")
                ongoingEvents.add(eventName)
            }
            if (ongoingEvents.isNotEmpty()) {
                val onevents = ongoingEvents.joinToString(", ")
                furhat.say(onevents)
                goto(PartTwo)
            } else {
                furhat.say("Currently, there are no ongoing events.")
                goto(PartTwo)
            }
        } else {
            furhat.say("Sorry, there was an error fetching information from the database.")
            goto(PartTwo)
        }
    }
}

val ListRecentlyConcludedEventsState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val lipasteventsutr = listOf(
            "Sure, here are the events that have recently concluded:",
            "Of course! Here are the events that just ended:",
            "Absolutely! These are the events that have recently finished:",
            "Sure thing! Take a look at the events that concluded recently:",
            "No problem! Here are the events that have just concluded:",
            "I'd be happy to help. Here are the events that finished recently:",
            "Certainly! Here are the events that have recently ended:",
            "Alright! Here’s a list of the events that have just concluded:",
            "Here are the events that have recently concluded:"
        )
        val lipasteventsrandomIndex = Random.nextInt(lipasteventsutr.size)
        val lipasteventsrandomutr = lipasteventsutr[lipasteventsrandomIndex]
        furhat.say(lipasteventsrandomutr)

        val currentDate = LocalDate.now().toString()
        val currentTime = LocalTime.now().toString().substring(0, 5) // HH:mm format

        val query = """
            SELECT event_name, start_time, end_time 
            FROM event 
            WHERE (event_date < '$currentDate') 
            OR (event_date = '$currentDate' AND end_time < '$currentTime')
            ORDER BY event_date DESC, end_time DESC
            LIMIT 3
        """
        val resultSet = DatabaseConnection.executeQuery(query)

        val recentlyConcludedEvents = mutableListOf<String>()

        if (resultSet != null) {
            while (resultSet.next()) {
                val eventName = resultSet.getString("event_name")
                recentlyConcludedEvents.add(eventName)
            }
            if (recentlyConcludedEvents.isNotEmpty()) {
                val rcevents = recentlyConcludedEvents.joinToString(", ")
                furhat.say(rcevents)
                goto(PartTwo)
            } else {
                furhat.say("Currently, we do not have any records of the past events.")
                goto(PartTwo)
            }
        } else {

            furhat.say("Sorry, there was an error fetching information from the database.")
            goto(PartTwo)
        }
    }
}

val ListUpcomingEventsState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val liupeventsutr = listOf(
            "Sure, here are the upcoming events:",
            "Of course! Here are the events that are coming up soon:",
            "Absolutely! These are the events that are scheduled to happen:",
            "Sure thing! Take a look at the upcoming events:",
            "No problem! Here are the events that are scheduled to happen:",
            "I'd be happy to help. Here are the events we have coming up:",
            "Certainly! Here are the events that are going to happen soon:",
            "Alright! Here’s a list of the upcoming events:",
            "Here are the events that are coming up:"
        )
        val liupeventsrandomIndex = Random.nextInt(liupeventsutr.size)
        val liupeventsrandomutr = liupeventsutr[liupeventsrandomIndex]
        furhat.say(liupeventsrandomutr)

        val currentDate = LocalDate.now().toString()
        val currentTime = LocalTime.now().toString().substring(0, 5) // HH:mm format

        val query = """
            SELECT event_name, event_date, start_time, end_time 
            FROM event 
            WHERE (event_date > '$currentDate') 
            OR (event_date = '$currentDate' AND start_time > '$currentTime')
            ORDER BY event_date ASC, start_time ASC LIMIT 3
        """
        val resultSet = DatabaseConnection.executeQuery(query)

        val upcomingEvents = mutableListOf<String>()

        if (resultSet != null) {
            while (resultSet.next()) {
                val eventName = resultSet.getString("event_name")
                val eventDate = resultSet.getString("event_date")
                val startTime = resultSet.getString("start_time")
                val endTime = resultSet.getString("end_time")
                upcomingEvents.add("$eventName on $eventDate from $startTime to $endTime")
            }
            if (upcomingEvents.isNotEmpty()) {
                val upevents = upcomingEvents.joinToString(", ")
                furhat.say(upevents)
                goto(PartTwo)
            } else {
                furhat.say("Currently, there are no upcoming events.")
                goto(PartTwo)
            }
        } else {
            furhat.say("Sorry, there was an error fetching information from the database.")
            goto(PartTwo)
        }
    }
}

val UnavailableState: State = state(Parent) {
    onEntry {
        GlobalState.interactionCount++

        val startIndex = entitiesString.indexOf('=') + 1
        var unavailablename = entitiesString.substring(startIndex).trim()
        if (unavailablename.endsWith("}")) {
            unavailablename = unavailablename.removeSuffix("}")
        }

        var Uname = unavailablename
        println(Uname)

        val booksFromDatabase: MutableList<String> = mutableListOf()
        val resultSetBookNames = DatabaseConnection.executeQuery("SELECT DISTINCT genre_name FROM unavailablekeywords")
        if (resultSetBookNames != null) {
            while (resultSetBookNames.next()) {
                val dbBook = resultSetBookNames.getString("genre_name")
                booksFromDatabase.add(dbBook)
            }
        }

        var maxSimilarity = 0.0
        var mostSimilarBook = Uname
        for (dbBook in booksFromDatabase) {
            val similarity = computeLevenshteinSimilarity(Uname, dbBook)
            println("Similarity between '$Uname' and '$dbBook': $similarity")
            if (similarity > maxSimilarity) {
                maxSimilarity = similarity
                mostSimilarBook = Uname
            }
        }

        val similarityThreshold = 0.7

        if (maxSimilarity >= similarityThreshold) {
            Uname = mostSimilarBook
            unavailablename = Uname
        }

        val query = "SELECT genre_name FROM unavailablekeywords WHERE genre_name = '$unavailablename'"
        val resultSet = DatabaseConnection.executeQuery(query)
        var nkey: String? = null

        if (resultSet != null && resultSet.next()) {
            nkey = resultSet.getString("genre_name")
        }

        if (nkey != null) {
            val nkeyutr = listOf("There are no books available with $nkey.", "We currently do not have any books with $nkey.",
                "No books are associated with this keyword $nkey in our collection.", "Our library does not feature any $nkey books.",
                "Unfortunately, we don't have any $nkey books at the moment.", "No books with this keyword $nkey are available right now.",
                "We don't have any books matching this keyword.", "Books of $nkey are not in our library.", "There are no available $nkey books.",
                "Our collection doesn't include any $nkey books.", "We have no books with $nkey in stock.", "At present, there are no books with $nkey.",
                "Books with this keyword $nkey are currently unavailable.", "We regret to inform you that we don't have $nkey books.",
                "$nkey is not represented in our library at this time.", "No books with $nkey can be found in our library.",
                "Our library lacks any $nkey books.", "There are no $nkey titles with in our collection.", "Sadly, we have no $nkey books.",
                "We do not have any books $nkey in our library.")
            val nkeyrandomIndex = Random.nextInt(nkeyutr.size)
            val nkeyrandomutr = nkeyutr[nkeyrandomIndex]
            furhat.say(nkeyrandomutr)
        }
        goto(PartTwo)
    }
}

val End: State = state(Parent) {

    onEntry {
        furhat.say("This is the end of this interaction. ")
        furhat.attendNobody()
        if (call(returnToIdle()) as Boolean) {
            goto(Idle)
        } else {
            furhat.attend(users.other)
            goto(mainFlow.startState())
        }
    }

}