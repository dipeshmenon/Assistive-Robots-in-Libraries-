package furhatos.app.templatelinearskill.flow

import furhatos.app.templatelinearskill.MyLinearSkill
import furhatos.app.templatelinearskill.setting.DISTANCE_TO_ENGAGE
import furhatos.app.templatelinearskill.setting.MAX_NUMBER_OF_USERS
import furhatos.app.templatelinearskill.setting.activate
import furhatos.app.templatelinearskill.setting.furhatPersona
import furhatos.autobehavior.enableSmileBack
import furhatos.flow.kotlin.State
import furhatos.flow.kotlin.furhat
import furhatos.flow.kotlin.state
import furhatos.flow.kotlin.users
import furhatos.nlu.LogisticMultiIntentClassifier
import furhatos.util.CommonUtils

// Get the log4J logger to print messages to the IntelliJ console and the log console in the web interface.
// Set the logging level in skill.properties
val log = CommonUtils.getLogger(MyLinearSkill::class.java)

/** State to initiate the skill, setting interaction parameters and starting the dialogue flow **/
val Init: State = state {
    init {
        /** Set our default interaction parameters */
        users.setSimpleEngagementPolicy(DISTANCE_TO_ENGAGE, MAX_NUMBER_OF_USERS)

        /** define our default smile back behavior */
        furhat.enableSmileBack = true

        /** enable alternate intent classifier
        see: https://docs.furhat.io/nlu/#alternative-classification */
        LogisticMultiIntentClassifier.setAsDefault()

    }
    onEntry {
        /** Set our main character - defined in personas */
        activate(furhatPersona)

        /** start interaction */
        when {
            users.hasAny() -> {
                log.debug("User present - start the interaction. ")
                furhat.attend(users.random)
                goto(mainFlow.startState())
            }
            else -> {
                log.debug("No users present - idling. ")
                goto(Idle) // Consider starting the interaction in Sleep.
            }
        }
    }
}

