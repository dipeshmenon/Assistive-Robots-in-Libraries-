package furhatos.app.templatelinearskill.nlu

import furhatos.app.templatelinearskill.setting.DatabaseConnection
import furhatos.nlu.*
import furhatos.util.Language

class LibraryTimings : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "what are the library timings",
            "tell me the library hours",
            "when is the library open",
            "tell me the library timings",
            "library opening hours",
            "library closing hours",
            "how many days is the library open in a week",
            "library days open",
            "library schedule",
            "library hours of operation",
            "when does the library open and close",
            "what time does the library open",
            "what time does the library close",
            "is the library open on weekends",
            "till what time can I renew books",
            "till when can I renew books",
            "operating hours",
            "opening hours",
            "closing hours",
            "library timings",
            "tell me the the library timings",
            "timings",
            "library time"
        )
    }
}

class GreetingsLib : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "Yo",
            "Hiya",
            "Howdy",
            "Hey there",
            "Hello",
            "Hi",
            "Hey",
            "Hola",
            "Bonjour",
            "Ciao",
            "Namaste",
            "Salam",
            "Aloha",
            "Konnichiwa",
            "Guten Tag",
            "Sup",
            "Long time no see",
            "Pleased to meet you",
            "Lovely day, isn't it?",
            "Good morning",
            "Good afternoon",
            "Good evening",
            "Greetings",
            "Howdy-do",
            "Hi there",
            "Well, hello there",
            "Nice to see you",
            "Good to see you again",
            "Good to meet you",
            "Nice to meet you",
            "Hey, nice to see you",
            "Hey, good to see you",
            "Hello again",
            "Hi, nice to see you"

        )
    }
}

class RecentBooksLib : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "list all recently added books",
            "show me the recently added books",
            "do you have any new books",
            "can you find recently added books",
            "what books were recently added",
            "I want to know about new books",
            "can you list all the new books",
            "show the recently added books",
            "find the recently added books",
            "what new books are there",
            "do you have any new books listed",
            "I am looking for new books",
            "which books are newly added",
            "could you tell me the books you recently added",
            "new books",
            "recent books",
            "tell me the recent books in the library",
            "newly added books",
            "new arrivals in books",
            "recent arrivals in books"
        )
    }
}

class OngoingEventsLib : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "What events are happening now?",
            "List the ongoing events",
            "Are there any events happening right now?",
            "Show me the events that are currently ongoing",
            "Do you have any events happening at this moment?",
            "What's happening now?",
            "What are the events happening in the institution?",
            "Tell me about ongoing events",
            "What events are going on now?",
            "what events are happening right now",
            "current events",
            "current happenings",
            "ongoing events",
            "tell me about the events going on",
            "any events going on right now",
            "what's happening around here",
            "list the current events",
            "list the present events",
            "present events",
            "present activities"

        )
    }
}

class RecentlyConcludedEventsLib : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "What events have recently concluded?",
            "List the recently concluded events",
            "Are there any events that just ended?",
            "Show me the events that recently concluded",
            "Do you have any events that finished recently?",
            "What events have just finished?",
            "Recently Concluded events in the library?",
            "Recently Concluded events in the institution?",
            "Recently Concluded events in the college?",
            "Tell me about recently concluded events",
            "What events have ended recently?",
            "What events happened in the past?",
            "List the past events",
            "Show me the events that happened earlier",
            "What events occurred in the past?",
            "Do you have any past events listed?",
            "What events were there before?",
            "Tell me about the past events",
            "Which events have concluded?",
            "recently concluded events",
            "list the past events",
            "past events",
            "recent activities"
        )
    }
}

class UpcomingEventsLib : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "What events are coming up?",
            "List the upcoming events",
            "Are there any events happening soon?",
            "Show me the events that are coming up",
            "Do you have any events scheduled for the future?",
            "What events are scheduled to happen?",
            "Tell me about upcoming events",
            "What events are going to happen soon?",
            "which events are scheduled",
            "upcoming events",
            "list the future events",
            "future events",
            "future activities"

        )
    }
}

class EndInteraction : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "Quit", "Exit","Stop", "End", "Bye", "Goodbye", "Cancel", "Terminate", "Leave", "Close", "Sentences",
            "I want to quit.", "Exit the chat.", "Stop the conversation.", "End this interaction.", "Goodbye, robot.",
            "I'm done talking.", "Cancel this session.", "Terminate the chat.", "I want to leave now.",
            "Close this chat.", "That's all for now.", "I don't need anything else.", "That's it.",
            "No more questions.", "I'll talk to you later.", "Good day", "Good night"
        )
    }
}


class FurServices : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "yourself",
            "your role",
            "how can you help me",
            "ask you",
            "what do you do here",
            "what can you do for me",
            "your services"
        )
    }
}

class CurrentTimeLib : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "what time is it",
            "what's the time",
            "current time please",
            "can you tell me the time",
            "do you know the time",
            "tell me the time",
            "time now",
            "what is the current time",
            "can you give me the time",
            "what is the time now",
            "what time is it now",
            "what's the time now",
            "what's the current time",
            "time please",
            "do you have the time",
            "what is the current date",
            "what day is it today",
            "what's the time and date",
            "current day and time",
            "can you tell me the date",
            "current date please",
            "what is today's date",
            "tell me the time and date",
            "day and date please",
            "what is the current time and day",
            "what day is it today",
            "what's the current date and time",
            "what's today",
            "what's the day today"
        )
    }
}


class HowQUTF : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "how's it", "how are you", "how's everything",
            "are things going",
            "your day been so far",
            "holding up",
            "doing today",
            "what's up",
            "how's it going",
            "how's it been",
            "how have you been",
            "how's life",
            "how are things",
            "how's your day",
            "how's your week",
            "how have things been",
            "how's your day treating you",
            "how's your week been",
            "how's everything going",
            "how's everything been",
            "how are you doing",
            "how's your morning",
            "how's your afternoon",
            "how's your evening",
            "how's life treating you",
            "how's everything with you",
            "how's your day going",
            "how's your week going",
            "how's your month going",
            "how are you holding up",
            "how have you been doing",
            "how's your time been",
            "how are things with you",
            "how's everything on your end",
            "how are you feeling",
            "how's your day shaping up",
            "how's your day been",
            "how's your day been treating you"
        )
    }
}

class HowGood : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "I am good", "fine", "great", "excellent",
            "I'm doing well", "pretty good", "I'm fantastic", "I'm wonderful",
            "couldn't be better", "I'm awesome", "doing great", "I'm really good",
            "I'm feeling amazing", "I'm happy", "all good", "in high spirits"
        )
    }
}

class HowBad : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "I have had better days", "I am bad", "not fine", "unwell",
            "I'm feeling down", "I'm not great", "I've been better", "I'm not doing well",
            "things could be better", "I'm feeling terrible", "I'm feeling awful", "I'm not okay",
            "having a rough day", "not so good", "I'm feeling low", "not my best day"
        )
    }
}

class HowMeh : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "meh", "neutral", "normal", "neither",
            "I'm okay", "so-so", "I'm alright", "not bad",
            "I'm fine", "could be better", "could be worse", "nothing special",
            "I'm average", "I'm feeling indifferent", "I'm in between", "just okay",
            "I'm managing", "I'm hanging in there", "I'm doing okay", "same as usual"
        )
    }
}

class HaveLocQUTF : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "ever been to",
            "made a trip to",
            "visited before?",
            "the chance to go to",
            "ever explored",
            "are you movable?",
            "have you ever traveled to",
            "been on a trip to",
            "ever gone to",
            "can you travel",
            "taken a visit to",
            "ever journeyed to",
            "had the opportunity to visit",
            "ever set foot in",
            "ever been in",
            "ever experienced",
            "ever been on a journey to",
            "had the chance to see",
            "ever checked out",
            "ever had the opportunity to go to",
            "ever had a trip to",
            "ever wandered to",
            "ever gone on a trip to",
            "ever seen",
            "ever had a visit to",
            "ever been on an excursion to",
            "ever ventured to",
            "ever toured",
            "ever explored the area of",
            "ever been in the vicinity of",
            "ever embarked on a trip to",
            "ever been on an adventure to"
        )
    }
}

class FinishProj : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "project",
            "finished that project",
            "completed the project",
            "project is done"

        )
    }
}

class BingeWatch : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "binge-watching",
            "new series",
            "Netflix series",
            "you watch",
            "glued to",
            "hooked on",
            "tv show", "series", "movies", "movie"
        )
    }
}

class HobbyAsk : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "hobby", "learnt", "practiced", "developed", "skilled", "interest", "interested", "interests"
        )
    }
}

class AgeAsk : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "What is your age?",
            "How old are you?",
            "What is your birth year?",
            "When were you born?",
            "What year were you born in?",
            "how old is Furhat",
            "what is Furhat's age",
            "when was Furhat created",
            "tell me about Furhat's age",
            "what age is Furhat",
            "how long has Furhat been around",
            "Furhat's birthdate",
            "when did Furhat first appear",
            "age of Furhat",
            "Furhat's inception year",
            "how many years old is Furhat",
            "since when has Furhat been around",
            "when was Furhat born",
            "what year was Furhat created",
            "what year was Furhat born",
            "how old is Furhat robot",
            "how many years has Furhat existed",
            "Furhat's age as of today",
            "how many years since Furhat was made",
            "tell me Furhat's age",
            "Furhat's age in years",
            "Furhat creation year",
            "when did Furhat come into existence",
            "how long has Furhat been operational",
            "what is the age of Furhat"

        )
    }
}

class GenderAsk : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "What is your gender?",
            "Are you categorized by gender?",
            "What gender do you align with?",
            "Is there a gender that applies to you?",
            "Do you have a gender specification?",
            "To what gender do you belong?",
            "I am male what are you",
            "I am female what are you",
            "I am non binary what are you",
            "I am transgender what are you"

        )
    }
}

class FunAsk : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "How do you like to spend your free time?",
            "What activities do you find enjoyable?",
            "How do you have fun?",
            "How do you prefer to have fun?",
            "What do you do for enjoyment?",
            "How do you like to relax and have fun?",
            "What do you do to relax and unwind?",
            "What do you enjoy doing in your spare time?",
            "what are your hobbies",
            "your hobbies",
            "what do you do in your free time"
        )
    }
}

class BookEntity(val bookName: String? = null, val locationNo: String? = null) : GenericEnumEntity(stemming = false) {

    override fun getEnumItems(lang: Language): List<EnumItem> {
        val bookItems = mutableListOf<EnumItem>()

        val resultSet = DatabaseConnection.executeQuery("SELECT Bname FROM BOOKS")

        // Iterate over the rows in the result set and add each book as an EnumItem
        while (resultSet != null && resultSet.next()) {
            val name = resultSet.getString("Bname")
            val variations = generateBookNameVariations(name)
            variations.forEach { variation ->
                val book = BookEntity(variation)
                bookItems.add(EnumItem(book, variation))
            }
        }
        return bookItems
    }

    private fun generateBookNameVariations(bookName: String): List<String> {
        val variations = mutableListOf<String>()
        variations.add(bookName)

        val words = bookName.split(" ")
        if (words.size > 1 && (words[0].equals("The", ignoreCase = true) ||
                    words[0].equals("A", ignoreCase = true) ||
                    words[0].equals("An", ignoreCase = true) ||
                    words[0].equals("To", ignoreCase = true))) {
            variations.add(words.subList(1, words.size).joinToString(" "))
        }

        if (bookName.contains(":")) {
            variations.add(bookName.replace(":", ""))
        }

        return variations.distinct()
    }
}

class BookLocationIntent : DynamicIntent(
    listOf(
        "location of book @bookName",
        "shelf of book @bookName",
        "where is book @bookName",
        "how far away is book @bookName",
        "is book @bookName available",
        "is book @bookName present in the library",
        "where can I find book @bookName?",
        "in which section is book @bookName located?",
        "could you tell me the shelf for book @bookName?",
        "how can I locate book @bookName?",
        "do you know the whereabouts of book @bookName?",
        "is book @bookName currently available?",
        "can you confirm if book @bookName is accessible?",
        "is book @bookName in stock?",
        "is book @bookName available for borrowing?",
        "could you check if @bookName is present in the library?",
        "is book @bookName present",
        "is book @bookName available",
        "do you have book @bookName",
        "where can I find book @bookName to renew",
        "Where can I find book @bookName for renewal?",
        "Can you tell me where book @bookName is located for renewal?",
        "I need to know the location of book @bookName for renewal.",
        "Could you direct me to book @bookName so I can renew it?",
        "Where should I go to renew book @bookName?",
        "I'm looking for book @bookName. Where can I renew it?",
        "I'd like to renew book @bookName. Where is it located?",
        "Please tell me where book @bookName is so I can renew it.",
        "Do you know the whereabouts of book @bookName for renewal?",
        "Can you guide me to book @bookName to renew it?",
        "where can I find book @bookName in order to renew it",
        "what is the location of book @bookName",
        "where is the book @bookName located",
        "is book @bookName in the library",
        "where can I find book @bookName",
        "which section is book @bookName in",
        "tell me the shelf for book @bookName",
        "how to locate book @bookName",
        "where is book @bookName at",
        "is book @bookName there",
        "can I borrow book @bookName",
        "do you have book @bookName",
        "where is book @bookName for renewal",
        "I need book @bookName location",
        "can I get book @bookName",
        "where is book @bookName kept",
        "how far is book @bookName",
        "can I find book @bookName",
        "is book @bookName present",
        "can you check book @bookName",
        "is book @bookName on shelf",
        "is book @bookName available to borrow",
        "do you have book @bookName in stock",
        "need book @bookName location",
        "where book @bookName at",
        "find book @bookName",
        "is book @bookName there for renewal",
        "tell me where book @bookName is",
        "what's the location of book @bookName",
        "can I renew book @bookName",
        "show me book @bookName",
        "guide me to book @bookName",
        "where I can renew book @bookName",
        "can you find book @bookName",
        "need to renew book @bookName",
        "is book @bookName in library",
        "confirm book @bookName location",
        "find book @bookName to renew",
        "check book @bookName availability",
        "locate book @bookName",
        "take me to book @bookName",
        "where is book @bookName located",
        "@bookName"
    ),
    mapOf("bookName" to BookEntity::class.java),
    Language.ENGLISH_US
) {
    override fun getNegativeExamples(lang: Language): List<String> {
        return listOf(
            "@bookName books",
            "@bookName book",
            "books @bookName"
        )
    }
}

class GenreEntity(val genreName: String? = null) : GenericEnumEntity(stemming = false) {

    override fun getEnumItems(lang: Language): List<EnumItem> {
        val genreItems = mutableListOf<EnumItem>()

        val resultSet = DatabaseConnection.executeQuery("SELECT DISTINCT genre FROM BOOKS")

        while (resultSet != null && resultSet.next()) {
            val genre = resultSet.getString("genre")
            val gen = GenreEntity(genre)
            genreItems.add(EnumItem(gen, genre))
        }
        return genreItems
    }
}

val BookGenreIntent = DynamicIntent(
    listOf(
        "list all books of @genreName genre",
        "list all books of genre @genreName ",
        "show me books in the @genreName genre",
        "show me books in the genre @genreName",
        "books of @genreName",
        "do you have books in the @genreName genre",
        "do you have books in the genre @genreName",
        "Can you find books in the genre categorized as @genreName?",
        "Can you find books categorized as @genreName genre?",
        "what books are available in the @genreName genre",
        "what books are available in the @genreName genre",
        "I want to read books in the @genreName genre",
        "I want to read books in the genre @genreName",
        "can you list books under @genreName genre",
        "can you list books under genre @genreName",
        "find books of @genreName genre",
        "find books of genre @genreName",
        "what books belong to the @genreName genre",
        "what books belong to the genre @genreName",
        "do you have any books in @genreName genre",
        "do you have any books in genre @genreName",
        "I am looking for books in the @genreName genre",
        "I am looking for books in the genre @genreName",
        "which books are categorized under @genreName genre",
        "which books are categorized under genre @genreName",
        "could you tell me the books in the @genreName genre",
        "could you tell me the books in the genre @genreName",
        "What books in the genre @genreName are available for me to renew?",
        "What @genreName genre books are available for me to renew?",
        "Can you show me which books in the @genreName genre I can renew?",
        "Can you show me which books in the genre @genreName I can renew?",
        "I'd like to see the books in the @genreName genre available for renewal.",
        "I'd like to see the books in the genre @genreName available for renewal.",
        "Show me the selection of books in the @genreName genre I can renew.",
        "Show me the selection of books in the genre @genreName I can renew.",
        "Please list the books in the @genreName genre I can renew.",
        "Please list the books in the genre @genreName I can renew.",
        "Could you tell me about the books in the @genreName genre available for renewal?",
        "Could you tell me about the books in the genre @genreName available for renewal?",
        "I'm interested in renewing books in the @genreName genre. What's available?",
        "I'm interested in renewing books in the genre @genreName. What's available?",
        "What are my options for renewing books in the @genreName genre?",
        "What are my options for renewing books in the genre @genreName?",
        "I want to renew books in the @genreName genre. Which ones are available?",
        "I want to renew books in the genre @genreName. Which ones are available?",
        "suggest me books in @genreName",
        "recommend me books in @genreName",
        "suggest books @genreName", "recommend books @genreName"


    ),
    mapOf("genreName" to GenreEntity::class.java),
    Language.ENGLISH_US
)

class AuthorEntity(val authorName: String? = null) : GenericEnumEntity(stemming = false) {

    override fun getEnumItems(lang: Language): List<EnumItem> {
        val authorItems = mutableListOf<EnumItem>()

        val resultSet = DatabaseConnection.executeQuery("SELECT DISTINCT author FROM BOOKS")

        // Iterate over the rows in the result set and add each author as an EnumItem
        while (resultSet != null && resultSet.next()) {
            val author = resultSet.getString("author")
            val variations = generateAuthorNameVariations(author)
            variations.forEach { variation ->
                val auth = AuthorEntity(variation)
                authorItems.add(EnumItem(auth, variation))
            }
        }
        return authorItems
    }

    private fun generateAuthorNameVariations(authorName: String): List<String> {
        val variations = mutableListOf<String>()
        variations.add(authorName)

        val words = authorName.split(" ")
        if (words.size == 3) {
            variations.add("${words[0]} ${words[1]}")
            variations.add("${words[0]} ${words[2]}")
            variations.add("${words[1]} ${words[2]}")
        }

        return variations.distinct()
    }
}


val BookAuthorIntent = DynamicIntent(
    listOf(
        "list all books by @authorName",
        "show me books written by @authorName",
        "do you have books by @authorName",
        "can you find books authored by @authorName",
        "what books are available by @authorName",
        "I want to read books by @authorName",
        "can you list books by @authorName",
        "show books written by @authorName",
        "find books by @authorName",
        "what books are authored by @authorName",
        "do you have any books by @authorName",
        "I am looking for books by @authorName",
        "which books are written by @authorName",
        "could you tell me the books by @authorName",
        "@authorName",
        "What books by @authorName can I renew?",
        "Can you show me which books by @authorName I can renew?",
        "I'd like to see the books authored by @authorName available for renewal.",
        "Show me the selection of books by @authorName I can renew.",
        "Which books by @authorName can I renew?",
        "Please list the books by @authorName I can renew.",
        "Could you tell me about the books authored by @authorName available for renewal?",
        "I'm interested in renewing books by @authorName. What's available?",
        "What are my options for renewing books by @authorName?",
        "I want to renew books authored by @authorName. Which ones are available?",
        "What books from @authorName can I renew?",
        "Can you show me which books from @authorName I can renew?",
        "I'd like to see the books from @authorName available for renewal.",
        "Show me the selection of books from @authorName I can renew.",
        "Which books from @authorName can I renew?",
        "Please list the books from @authorName I can renew.",
        "I'm interested in renewing books from @authorName. What's available?",
        "What are my options for renewing books from @authorName?",
        "suggest me books of @authorName",
        "recommend me books of @authorName",
        "suggest books @authorName", "recommend books @authorName"

    ),
    mapOf("authorName" to AuthorEntity::class.java),
    Language.ENGLISH_US
)

val RecentBooksByAuthorIntent = DynamicIntent(
    listOf(
        "list all recently added books by @authorName",
        "show me the recently added books by @authorName",
        "do you have any new books by @authorName",
        "can you find recently added books by @authorName",
        "what books were recently added by @authorName",
        "I want to know about new books by @authorName",
        "can you list all the new books by @authorName",
        "show the recently added books by @authorName",
        "find the recently added books by @authorName",
        "what new books are there by @authorName",
        "do you have any new books listed by @authorName",
        "I am looking for new books by @authorName",
        "which books are newly added by @authorName",
        "could you tell me the books you recently added by @authorName",
        "new books by @authorName",
        "most recent books by @authorName",
        "recent books by @authorName",
        "latest books by @authorName",
        "latest books of @authorName"

    ),
    mapOf("authorName" to AuthorEntity::class.java),
    Language.ENGLISH_US
)

val MostRenewedAuthorIntent = DynamicIntent(
    listOf(
        "show the most renewed books by @authorName",
        "list the top renewed books by @authorName",
        "most popular books by @authorName",
        "most checked out books by @authorName",
        "what are the popular books by @authorName",
        "most renewed books by @authorName",
        "top books by @authorName",
        "most popular books by @authorName",
        "books by @authorName with the highest renewals",
        "what are the most renewed books by @authorName",
        "give me the most renewed books by @authorName",
        "which books by @authorName are renewed the most",
        "tell me the top renewed books by @authorName",
        "I want to know the most renewed books by @authorName",
        "list the books by @authorName that are most renewed",
        "Show the most renewed books by @authorName that I can renew,",
        "List the most renewed books by @authorName available for renewal,",
        "What are the most renewed books by @authorName that I can renew?",
        "Can you show me the most renewed books by @authorName available for renewal?",
        "Which are the most renewed books by @authorName that I can renew?",
        "I want to see the most renewed books by @authorName that I can renew",
        "Display the most renewed books by @authorName available for renewal",
        "Find the most renewed books by @authorName that I can renew",
        "Show me the top renewed books by @authorName that I can renew",
        "Can you list the most renewed books by @authorName that I can renew?",
        "Which are the top renewed books by @authorName available for renewal?",
        "Tell me the most renewed books by @authorName that I can renew,",
        "What are the top renewed books by @authorName that I can renew?",
        "Display the top renewed books by @authorName available for renewal",
        "Show the most frequently renewed books by @authorName that I can renew",
        "most popular books in @authorName",
        "most popular @authorName books",
        "most renewed books in @authorName"

    ),
    mapOf("authorName" to AuthorEntity::class.java),
    Language.ENGLISH_US
)

class SubjectEntity(val subjectName: String? = null) : GenericEnumEntity(stemming = false) {

    override fun getEnumItems(lang: Language): List<EnumItem> {
        val subjectItems = mutableListOf<EnumItem>()

        val resultSet = DatabaseConnection.executeQuery("SELECT DISTINCT subject FROM BOOKS")

        while (resultSet != null && resultSet.next()) {
            val subject = resultSet.getString("subject")
            val sub = SubjectEntity(subject)
            subjectItems.add(EnumItem(sub, subject))
        }
        return subjectItems
    }
}

val BookSubjectIntent = DynamicIntent(
    listOf(
        "list all books on @subjectName",
        "show me books about @subjectName",
        "do you have books on @subjectName",
        "can you find books related to @subjectName",
        "what books are available on @subjectName",
        "I want to read books about @subjectName",
        "can you list books on @subjectName",
        "show books related to @subjectName",
        "find books about @subjectName",
        "what books are about @subjectName",
        "do you have any books on @subjectName",
        "I am looking for books on @subjectName",
        "which books are on @subjectName",
        "could you tell me the books on @subjectName",
        "list all books in the subject of @subjectName",
        "show me books in the subject of @subjectName",
        "do you have books in the subject of @subjectName",
        "can you find books in the subject of @subjectName",
        "what books are available in the subject of @subjectName",
        "I want to read books in the subject of @subjectName",
        "can you list books in the subject of @subjectName",
        "show books in the subject of @subjectName",
        "find books in the subject of @subjectName",
        "what books are in the subject of @subjectName",
        "do you have any books in the subject of @subjectName",
        "I am looking for books in the subject of @subjectName",
        "which books are in the subject of @subjectName",
        "could you tell me the books in the subject of @subjectName",
        "list of @subjectName books",
        "What books from @subjectName can I renew?",
        "Can you show me which books from @subjectName I can renew?",
        "I'd like to see the books from @subjectName available for renewal.",
        "Show me the selection of books from @subjectName I can renew.",
        "Which books from @subjectName can I renew?",
        "Please list the books from @subjectName I can renew.",
        "Could you tell me about the books in the @subjectName category available for renewal?",
        "I'm interested in renewing books from @subjectName. What's available?",
        "What are my options for renewing books in the @subjectName category?",
        "I want to renew books related to @subjectName. Which ones are available?",
        "@subjectName",
        "suggest me books in @subjectName",
        "recommend me books in @subjectName",
        "suggest books @subjectName", "recommend books @subjectName"


    ),
    mapOf("subjectName" to SubjectEntity::class.java),
    Language.ENGLISH_US
)

class KeywordEntity(val keyword: String? = null) : GenericEnumEntity(stemming = false) {

    override fun getEnumItems(lang: Language): List<EnumItem> {
        val keywordItems = mutableListOf<EnumItem>()

        val resultSet = DatabaseConnection.executeQuery("SELECT keywords FROM BOOKS")

        while (resultSet != null && resultSet.next()) {
            val keywordsString = resultSet.getString("keywords")
            val keywords = keywordsString.split(",").map { it.trim() }

            keywords.forEach { keyword ->
                val keyEntity = KeywordEntity(keyword)
                keywordItems.add(EnumItem(keyEntity, keyword))
            }
        }
        return keywordItems
    }
}

val BookKeywordIntent = DynamicIntent(
    listOf(
        "show all books that are about @keyword",
        "list all books that mention @keyword",
        "show me books with the keyword @keyword",
        "do you have books tagged with @keyword",
        "can you find books with the keyword @keyword",
        "what books are available with the keyword @keyword",
        "I want to read books with the keyword @keyword",
        "can you list books with the keyword @keyword",
        "show books tagged with @keyword",
        "find books with the keyword @keyword",
        "what books are tagged with @keyword",
        "do you have any books with the keyword @keyword",
        "I am looking for books with the keyword @keyword",
        "which books are tagged with @keyword",
        "could you tell me the books with the keyword @keyword",
        "list all books that reference @keyword",
        "show me books that include @keyword",
        "find books related to @keyword",
        "books that talk about @keyword",
        "books that discuss @keyword",
        "books mentioning @keyword",
        "list of @keyword books",
        "What books related to @keyword can I renew?",
        "Can you show me which books related to @keyword I can renew?",
        "I'd like to see the books related to @keyword available for renewal.",
        "Show me the selection of books related to @keyword I can renew.",
        "Which books related to @keyword can I renew?",
        "Please list the books related to @keyword I can renew.",
        "Could you tell me about the books associated with @keyword available for renewal?",
        "I'm interested in renewing books related to @keyword. What's available?",
        "What are my options for renewing books associated with @keyword?",
        "I want to renew books connected to @keyword. Which ones are available?",
        "@keyword",
        "suggest me books in @keyword",
        "recommend me books in @keyword",
        "suggest books @keyword", "recommend books @keyword"

    ),
    mapOf("keyword" to KeywordEntity::class.java),
    Language.ENGLISH_US
)


val BookSimilarityIntent = DynamicIntent(
    listOf("show books similar to @bookName", "list books that are similar to @bookName", "find books like @bookName", "do you have books similar to @bookName",
        "can you find books related to @bookName", "what books are like @bookName", "I want to read books similar to @bookName", "can you list books like @bookName",
        "show books related to @bookName", "find books that are similar to @bookName", "which books are similar to @bookName", "do you have any books like @bookName",
        "I am looking for books similar to @bookName", "could you tell me the books similar to @bookName", "which books are alike @bookName","show books similar to @bookName to renew","Show me books that are similar to @bookName available for renewal.",
        "What books are like @bookName that I can renew?","I'm looking for books similar to @bookName to renew.","Can you recommend books similar to @bookName for renewal?",
        "Find books akin to @bookName that I can renew.","I'd like to explore books resembling @bookName available for renewal.","Could you suggest books related to @bookName that I can renew?",
        "Are there any books comparable to @bookName that I can renew?", "recommend me books similar to @bookName", "recommend me books like @bookName", "suggest books like @bookName", "suggest books @bookName", "recommend books @bookName"),
    mapOf("bookName" to BookEntity::class.java),
    Language.ENGLISH_US
)

class ListGenreAvail : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "list all genres", "show me the available genres",
            "do you have different genres", "can you find genres available",
            "what genres are available", "I want to know about genres",
            "can you list all the genres", "show the available genres",
            "find the available genres", "what genres are there",
            "do you have any genres listed", "I am looking for genres",
            "which genres are available", "could you tell me the genres you have",
            "Show me all genres available for renewal.",
            "List genres that I can renew.",
            "What genres can I renew?",
            "Can you display all genres available for renewal?",
            "Which genres are available for renewal?",
            "I want to see genres that I can renew.",
            "Show genres available for renewal.",
            "List all genres I can renew.",
            "Find genres that I can renew.",
            "Display genres available for renewal.",
            "genres"
        )
    }
}

class ListAuthorAvail : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "list all authors", "show me the available authors", "do you have different authors",
            "can you find authors available", "what authors are available", "I want to know about authors",
            "can you list all the authors", "show the available authors", "find the available authors",
            "what authors are there", "do you have any authors listed", "I am looking for authors",
            "which authors are available", "could you tell me the authors you have", "authors"
        )
    }
}

class ListSubjectsAvail : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "list all subjects", "show me the available subjects",
            "do you have different subjects", "can you find subjects available",
            "what subjects are available", "I want to know about subjects",
            "can you list all the subjects", "show the available subjects",
            "find the available subjects", "what subjects are there", "do you have any subjects listed",
            "I am looking for subjects", "which subjects are available",
            "could you tell me the subjects you have",
            "Show me all subjects with books available for renewal.",
            "List subjects whose books I can renew.",
            "What subjects have books that I can renew?",
            "Can you display all subjects with books available for renewal?",
            "Which subjects have books available for renewal?",
            "I want to see subjects whose books I can renew.",
            "Show subjects with books available for renewal.",
            "List all subjects with books I can renew.",
            "Find subjects whose books I can renew.",
            "Display subjects with books available for renewal.",
            "Can you list all subjects whose books I can renew?",
            "What are the subjects with books that I can renew?",
            "Show me the subjects whose books I can renew.",
            "Which subjects' books are available for renewal?",
            "Can you show me subjects with books to renew?",
            "subjects"
        )
    }
}

val RecentBooksByGenreIntent = DynamicIntent(
    listOf(
        "list all recently added books in @genreName",
        "show me the recently added books in @genreName",
        "do you have any new books in @genreName",
        "can you find recently added books in @genreName",
        "what books were recently added in @genreName",
        "I want to know about new books in @genreName",
        "can you list all the new books in @genreName",
        "show the recently added books in @genreName",
        "find the recently added books in @genreName",
        "what new books are there in @genreName",
        "do you have any new books listed in @genreName",
        "I am looking for new books in @genreName",
        "which books are newly added in @genreName",
        "could you tell me the books you recently added in @genreName",
        "new books in @genreName",
        "most recent books by @genreName",
        "recent books by @genreName",
        "latest books by @genreName",
        "latest books of @genreName",
        "newly added books of @genreName",
        "new arrivals @genreName",
        "recent arrivals @genreName"
    ),
    mapOf("genreName" to GenreEntity::class.java),
    Language.ENGLISH_US
)

val RecentBooksBySubjectIntent = DynamicIntent(
    listOf(
        "list all recently added books in @subjectName",
        "show me the recently added books in @subjectName",
        "do you have any new books in @subjectName",
        "can you find recently added books in @subjectName",
        "what books were recently added in @subjectName",
        "I want to know about new books in @subjectName",
        "can you list all the new books in @subjectName",
        "show the recently added books in @subjectName",
        "find the recently added books in @subjectName",
        "what new books are there in @subjectName",
        "do you have any new books listed in @subjectName",
        "I am looking for new books in @subjectName",
        "which books are newly added in @subjectName",
        "could you tell me the books you recently added in @subjectName",
        "new books in @subjectName",
        "most recent books by @subjectName",
        "recent books by @subjectName",
        "latest books of @subjectName",
        "latest books by @subjectName",
        "newly added books of @subjectName",
        "new arrivals @subjectName",
        "recent arrivals @subjectName"
    ),
    mapOf("subjectName" to SubjectEntity::class.java),
    Language.ENGLISH_US
)

val RecentBooksByKeywordIntent = DynamicIntent(
    listOf(
        "list all recently added books with keyword @keyword",
        "show me the recently added books with keyword @keyword",
        "do you have any new books with keyword @keyword",
        "can you find recently added books with keyword @keyword",
        "what books were recently added with keyword @keyword",
        "I want to know about new books with keyword @keyword",
        "can you list all the new books with keyword @keyword",
        "show the recently added books with keyword @keyword",
        "find the recently added books with keyword @keyword",
        "what new books are there with keyword @keyword",
        "do you have any new books listed with keyword @keyword",
        "I am looking for new books with keyword @keyword",
        "which books are newly added with keyword @keyword",
        "could you tell me the books you recently added with keyword @keyword",
        "new books with keyword @keyword",
        "list all recently added books of @keyword",
        "show me the recently added books of @keyword",
        "do you have any new books of @keyword",
        "can you find recently added books of @keyword",
        "what books were recently added of @keyword",
        "I want to know about new books of @keyword",
        "can you list all the new books of @keyword",
        "show the recently added books of @keyword",
        "find the recently added books of @keyword",
        "what new books are there of @keyword",
        "do you have any new books listed of @keyword",
        "I am looking for new books of @keyword",
        "which books are newly added of @keyword",
        "could you tell me the books you recently added of @keyword",
        "new books of @keyword",
        "most recent books by @keyword",
        "recent books by @keyword",
        "latest books of @keyword",
        "latest books by @keyword",
        "newly added books by @keyword",
        "new arrivals @keyword",
        "recent arrivals @keyword"
    ),
    mapOf("keyword" to KeywordEntity::class.java),
    Language.ENGLISH_US
)

class LibMemAvail : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "join the library",
            "what do I get as a member",
            "library member",
            "perks",
            "library membership",
            "sign up",
            "enroll",
            "member of the library",
            "can you tell me how to become a member of the library and what advantages it offers",
            "what do I need to do to become a library member, and what privileges do I receive",
            "library card",
            "membership benefits",
            "membership process",
            "value of the membership",
            "membership",
            "membership options",
            "membership details"

        )
    }
}

val MostRenewedGenreIntent = DynamicIntent(
    listOf(
        "show most renewed books in @genreName",
        "list top renewed books in @genreName",
        "most popular books in @genreName",
        "most checked out books in @genreName",
        "what are the popular books in @genreName",
        "most renewed @genreName books",
        "top @genreName books",
        "most popular @genreName books",
        "books in @genreName with highest renewals",
        "renewed @genreName", "popular @genreName",
        "Show the most renewed books in @genreName that I can renew.",
        "List the most renewed books in @genreName available for renewal.",
        "What are the most renewed books in @genreName that I can renew?",
        "Can you show me the most renewed books in @genreName available for renewal?",
        "Which are the most renewed books in @genreName that I can renew?",
        "I want to see the most renewed books in @genreName that I can renew.",
        "Display the most renewed books in @genreName available for renewal.",
        "Find the most renewed books in @genreName that I can renew.",
        "Show me the top renewed books in @genreName that I can renew.",
        "Can you list the most renewed books in @genreName that I can renew?",
        "Which are the top renewed books in @genreName available for renewal?",
        "Tell me the most renewed books in @genreName that I can renew.",
        "What are the top renewed books in @genreName that I can renew?",
        "Display the top renewed books in @genreName available for renewal.",
        "Show the most frequently renewed books in @genreName that I can renew.",
        "most popular books in @genreName",
        "most popular @genreName books",
        "most renewed books in @genreName"
    ),
    mapOf("genreName" to GenreEntity::class.java),
    Language.ENGLISH_US
)

val MostRenewedSubjectIntent = DynamicIntent(
    listOf(
        "show the most renewed books in @subjectName",
        "list the top renewed books in @subjectName",
        "most popular books in @subjectName",
        "most checked out books in @subjectName",
        "what are the popular books in @subjectName",
        "most renewed books in @subjectName",
        "top books in @subjectName",
        "most popular books in @subjectName",
        "books in @subjectName with the highest renewals",
        "Show the most renewed books in @subjectName that I can renew.",
        "List the most renewed books in @subjectName available for renewal.",
        "What are the most renewed books in @subjectName that I can renew?",
        "Can you show me the most renewed books in @subjectName available for renewal?",
        "Which are the most renewed books in @subjectName that I can renew?",
        "I want to see the most renewed books in @subjectName that I can renew.",
        "Display the most renewed books in @subjectName available for renewal.",
        "Find the most renewed books in @subjectName that I can renew.",
        "Show me the top renewed books in @subjectName that I can renew.",
        "Can you list the most renewed books in @subjectName that I can renew?",
        "Which are the top renewed books in @subjectName available for renewal?",
        "Tell me the most renewed books in @subjectName that I can renew.",
        "What are the top renewed books in @subjectName that I can renew?",
        "Display the top renewed books in @subjectName available for renewal.",
        "Show the most frequently renewed books in @subjectName that I can renew.",
        "most popular books in @subjectName",
        "most popular @subjectName books",
        "most renewed books in @subjectName"

    ),
    mapOf("subjectName" to SubjectEntity::class.java),
    Language.ENGLISH_US
)

val MostRenewedBooksKeywordIntent = DynamicIntent(
    listOf(
        "show the most renewed @keyword books",
        "list the top renewed @keyword books",
        "most popular @keyword books",
        "most checked out @keyword books",
        "what are the popular @keyword books",
        "most renewed @keyword books",
        "top @keyword books",
        "most popular @keyword books",
        "books with keywords @keyword with the highest renewals",
        "what are the most renewed @keyword books",
        "give me the most renewed @keyword books",
        "which @keyword books are renewed the most",
        "tell me the top renewed @keyword books",
        "I want to know the most renewed @keyword books",
        "list the @keyword books that are most renewed",
        "Show the most renewed @keyword books that I can renew,",
        "List the most renewed @keyword books available for renewal,",
        "What are the most renewed @keyword books that I can renew?",
        "Can you show me the most renewed @keyword books available for renewal?",
        "Which are the most renewed @keyword books that I can renew?",
        "I want to see the most renewed @keyword books that I can renew",
        "Display the most renewed @keyword books available for renewal,",
        "Find the most renewed @keyword books that I can renew",
        "Show me the top renewed @keyword books that I can renew",
        "Can you list the most renewed @keyword books that I can renew?",
        "Which are the top renewed @keyword books available for renewal?",
        "Tell me the most renewed @keyword books that I can renew,",
        "What are the top renewed @keyword books that I can renew?",
        "Display the top renewed @keyword books available for renewal,",
        "Show the most frequently renewed @keyword books that I can renew,",
        "most popular books in @keyword",
        "most popular @keyword books",
        "most renewed books in @keyword"
    ),
    mapOf("keyword" to KeywordEntity::class.java),
    Language.ENGLISH_US
)

val BookNameGenreIntent = DynamicIntent(
    listOf(
        "what is the genre of @bookName",
        "tell me the genre of@bookName",
        "what genre is @bookName",
        "which genre does @bookName belong to",
        "what category is @bookName",
        "what type of book is @bookName",
        "what is the genre for the book @bookName",
        "which genre is the book @bookName in",
        "what's the genre of @bookName",
        "What is the genre of @bookName that I can renew?",
        "Can you tell me the genre of @bookName that I can renew?",
        "I want to know the genre of @bookName that I can renew,",
        "Which genre does @bookName belong to that I can renew?",
        "Show me the genre of @bookName that I can renew",
        "Tell me the genre of @bookName that I can renew",
        "What genre is @bookName that I can renew?",
        "Can you show me the genre of @bookName that I can renew?",
        "I'd like to know the genre of @bookName that I can renew",
        "Find out the genre of @bookName that I can renew",
        "Which genre is @bookName that I can renew?",
        "I need to know the genre of @bookName that I can renew",
        "What category is @bookName that I can renew?",
        "Identify the genre of @bookName that I can renew,",
        "What genre classification does @bookName have that I can renew?"
    ),mapOf("bookName" to BookEntity::class.java),
    Language.ENGLISH_US
)

val BookNameSubjectIntent = DynamicIntent(
    listOf(
        "what is the subject of @bookName",
        "tell me the subject of @bookName",
        "what subject is @bookName",
        "which subject does @bookName belong to",
        "what category is @bookName",
        "what type of book is @bookName",
        "what is the subject for the book @bookName",
        "which subject is the book @bookName in",
        "what's the subject of @bookName",
        "What is the subject of @bookName that I can renew?",
        "Can you tell me the subject of @bookName that I can renew?",
        "I want to know the subject of @bookName that I can renew",
        "Which subject does @bookName cover that I can renew?",
        "Show me the subject of @bookName that I can renew",
        "Tell me the subject of @bookName that I can renew",
        "What subject is @bookName that I can renew?",
        "Can you show me the subject of @bookName that I can renew?",
        "I'd like to know the subject of @bookName that I can renew",
        "Find out the subject of @bookName that I can renew",
        "Which subject is @bookName that I can renew?",
        "I need to know the subject of @bookName that I can renew",
        "What topic does @bookName cover that I can renew?",
        "Identify the subject of @bookName that I can renew",
        "What is the theme of @bookName that I can renew?"
    ),
    mapOf("bookName" to BookEntity::class.java),
    Language.ENGLISH_US
)

class LocationNoEntity(val locationNo: String? = null) : GenericEnumEntity(stemming = false) {

    override fun getEnumItems(lang: Language): List<EnumItem> {
        val locationItems = mutableListOf<EnumItem>()

        val resultSet = DatabaseConnection.executeQuery("SELECT DISTINCT location_no FROM BOOKS")

        while (resultSet != null && resultSet.next()) {
            val location = resultSet.getString("location_no")
            val loc = LocationNoEntity(location)
            locationItems.add(EnumItem(loc, location))
        }
        return locationItems
    }
}


val BooksByLocationIntent = DynamicIntent(
    listOf(
        "show me all the books in location number @locationNo",
        "list all books in location number @locationNo",
        "books available in location number @locationNo",
        "what books are in location number @locationNo",
        "give me the books in location number @locationNo",
        "which books are located in location number @locationNo",
        "tell me the books in location number @locationNo",
        "list the books in location number @locationNo",
        "at @locationNo", "in @locationNo", "for @locationNo",
        "Show me all the books in location number @locationNo that I can renew",
        "List all the books in location number @locationNo that I can renew",
        "What books are available for renewal in location number @locationNo?",
        "Can you show me the books in location number @locationNo that I can renew?",
        "Which books in location number @locationNo can I renew?",
        "I want to see all the books in location number @locationNo that I can renew",
        "Display all the books in location number @locationNo available for renewal",
        "Find all the books in location number @locationNo that I can renew",
        "Show me the books in location number @locationNo available for renewal",
        "Can you list the books in location number @locationNo that I can renew?",
        "Which books are in location number @locationNo that I can renew?",
        "Tell me all the books in location number @locationNo that I can renew",
        "What are the books in location number @locationNo that I can renew?",
        "Display the books in location number @locationNo available for renewal",
        "Show the books in location number @locationNo that I can renew"
    ),
    mapOf("locationNo" to LocationNoEntity::class.java),
    Language.ENGLISH_US
)

val BookInfoIntent = DynamicIntent(
    listOf(
        "tell me about the book @bookName",
        "give me information about the book @bookName",
        "who is the author of @bookName",
        "what is the description of @bookName",
        "I want to know about @bookName",
        "details of the book @bookName",
        "information about @bookName",
        "describe the book @bookName",
        "author of @bookName",
        "description of @bookName",
        "who wrote @bookName",
        "summary of @bookName",
        "Tell me about the book @bookName that I want to renew",
        "Can you describe the book @bookName that I want to renew?",
        "I want information about the book @bookName that I want to renew,",
        "What can you tell me about the book @bookName that I want to renew?",
        "Show me details about the book @bookName that I want to renew",
        "Describe the book @bookName that I want to renew",
        "Give me information on the book @bookName that I want to renew",
        "Provide details about the book @bookName that I want to renew",
        "Tell me more about the book @bookName that I want to renew",
        "I'd like to know about the book @bookName that I want to renew",
        "Find out about the book @bookName that I want to renew",
        "What is the story of the book @bookName that I want to renew?",
        "Learn about the book @bookName that I want to renew",
        "What details can you give me about the book @bookName that I want to renew?",
        "Discover more about the book @bookName that I want to renew",
        "tell me about @bookName"
    ),
    mapOf("bookName" to BookEntity::class.java),
    Language.ENGLISH_US
)

class UnavailableEntity(val nothinName: String? = null) : GenericEnumEntity(stemming = false) {

    override fun getEnumItems(lang: Language): List<EnumItem> {
        val nuthinitems = mutableListOf<EnumItem>()

        val resultSet = DatabaseConnection.executeQuery("SELECT DISTINCT genre_name FROM unavailablekeywords")

        while (resultSet != null && resultSet.next()) {
            val nonekeyword = resultSet.getString("genre_name")
            val nkey = UnavailableEntity(nonekeyword)
            nuthinitems.add(EnumItem(nkey, nonekeyword))
        }
        return nuthinitems
    }
}

val UnavailableIntent = DynamicIntent(
    listOf(
        "tell me about the book @nothinName",
        "give me information about the book @nothinName",
        "who is the author of @nothinName",
        "what is the description of @nothinName",
        "I want to know about @nothinName",
        "details of the book @nothinName",
        "information about @nothinName",
        "describe the book @nothinName",
        "author of @nothinName",
        "description of @nothinName",
        "who wrote @nothinName",
        "summary of @nothinName",
        "Tell me about the book @nothinName that I want to renew",
        "Can you describe the book @nothinName that I want to renew?",
        "I want information about the book @nothinName that I want to renew,",
        "What can you tell me about the book @nothinName that I want to renew?",
        "Show me details about the book @nothinName that I want to renew",
        "Describe the book @nothinName that I want to renew",
        "Give me information on the book @nothinName that I want to renew",
        "Provide details about the book @nothinName that I want to renew",
        "Tell me more about the book @nothinName that I want to renew",
        "I'd like to know about the book @nothinName that I want to renew",
        "Find out about the book @nothinName that I want to renew",
        "What is the story of the book @nothinName that I want to renew?",
        "Learn about the book @nothinName that I want to renew",
        "What details can you give me about the book @nothinName that I want to renew?",
        "Discover more about the book @nothinName that I want to renew",
        "tell me about @nothinName",
        "show the most renewed @nothinName books",
        "list the top renewed @nothinName books",
        "most popular @nothinName books",
        "most checked out @nothinName books",
        "what are the popular @nothinName books",
        "most renewed @nothinName books",
        "top @nothinName books",
        "most popular @nothinName books",
        "books with keywords @nothinName with the highest renewals",
        "what are the most renewed @nothinName books",
        "give me the most renewed @nothinName books",
        "which @nothinName books are renewed the most",
        "tell me the top renewed @nothinName books",
        "I want to know the most renewed @nothinName books",
        "list the @nothinName books that are most renewed",
        "Show the most renewed @nothinName books that I can renew,",
        "List the most renewed @nothinName books available for renewal,",
        "What are the most renewed @nothinName books that I can renew?",
        "Can you show me the most renewed @nothinName books available for renewal?",
        "Which are the most renewed @nothinName books that I can renew?",
        "I want to see the most renewed @nothinName books that I can renew",
        "Display the most renewed @nothinName books available for renewal,",
        "Find the most renewed @nothinName books that I can renew",
        "Show me the top renewed @nothinName books that I can renew",
        "Can you list the most renewed @nothinName books that I can renew?",
        "Which are the top renewed @nothinName books available for renewal?",
        "Tell me the most renewed @nothinName books that I can renew,",
        "What are the top renewed @nothinName books that I can renew?",
        "Display the top renewed @nothinName books available for renewal,",
        "Show the most frequently renewed @nothinName books that I can renew,",
        "most popular books in @nothinName",
        "most popular @nothinName books",
        "most renewed books in @nothinName",
        "show the most renewed books in @nothinName",
        "list the top renewed books in @nothinName",
        "most popular books in @nothinName",
        "most checked out books in @nothinName",
        "what are the popular books in @nothinName",
        "most renewed books in @nothinName",
        "top books in @nothinName",
        "most popular books in @nothinName",
        "books in @nothinName with the highest renewals",
        "Show the most renewed books in @nothinName that I can renew.",
        "List the most renewed books in @nothinName available for renewal.",
        "What are the most renewed books in @nothinName that I can renew?",
        "Can you show me the most renewed books in @nothinName available for renewal?",
        "Which are the most renewed books in @nothinName that I can renew?",
        "I want to see the most renewed books in @nothinName that I can renew.",
        "Display the most renewed books in @nothinName available for renewal.",
        "Find the most renewed books in @nothinName that I can renew.",
        "Show me the top renewed books in @nothinName that I can renew.",
        "Can you list the most renewed books in @nothinName that I can renew?",
        "Which are the top renewed books in @nothinName available for renewal?",
        "Tell me the most renewed books in @nothinName that I can renew.",
        "What are the top renewed books in @nothinName that I can renew?",
        "Display the top renewed books in @nothinName available for renewal.",
        "Show the most frequently renewed books in @nothinName that I can renew.",
        "most popular books in @nothinName",
        "most popular @nothinName books",
        "most renewed books in @nothinName",
        "show most renewed books in @nothinName",
        "list top renewed books in @nothinName",
        "most popular books in @nothinName",
        "most checked out books in @nothinName",
        "what are the popular books in @nothinName",
        "most renewed @nothinName books",
        "top @nothinName books",
        "most popular @nothinName books",
        "books in @nothinName with highest renewals",
        "renewed @nothinName", "popular @nothinName",
        "Show the most renewed books in @nothinName that I can renew.",
        "List the most renewed books in @nothinName available for renewal.",
        "What are the most renewed books in @nothinName that I can renew?",
        "Can you show me the most renewed books in @nothinName available for renewal?",
        "Which are the most renewed books in @nothinName that I can renew?",
        "I want to see the most renewed books in @nothinName that I can renew.",
        "Display the most renewed books in @nothinName available for renewal.",
        "Find the most renewed books in @nothinName that I can renew.",
        "Show me the top renewed books in @nothinName that I can renew.",
        "Can you list the most renewed books in @nothinName that I can renew?",
        "Which are the top renewed books in @nothinName available for renewal?",
        "Tell me the most renewed books in @nothinName that I can renew.",
        "What are the top renewed books in @nothinName that I can renew?",
        "Display the top renewed books in @nothinName available for renewal.",
        "Show the most frequently renewed books in @nothinName that I can renew.",
        "most popular books in @nothinName",
        "most popular @nothinName books",
        "most renewed books in @nothinName",
        "list all recently added books with keyword @nothinName",
        "show me the recently added books with keyword @nothinName",
        "do you have any new books with keyword @nothinName",
        "can you find recently added books with keyword @nothinName",
        "what books were recently added with keyword @nothinName",
        "I want to know about new books with keyword @nothinName",
        "can you list all the new books with keyword @nothinName",
        "show the recently added books with keyword @nothinName",
        "find the recently added books with keyword @nothinName",
        "what new books are there with keyword @nothinName",
        "do you have any new books listed with keyword @nothinName",
        "I am looking for new books with keyword @nothinName",
        "which books are newly added with keyword @nothinName",
        "could you tell me the books you recently added with keyword @nothinName",
        "new books with keyword @nothinName",
        "list all recently added books of @nothinName",
        "show me the recently added books of @nothinName",
        "do you have any new books of @nothinName",
        "can you find recently added books of @nothinName",
        "what books were recently added of @nothinName",
        "I want to know about new books of @nothinName",
        "can you list all the new books of @nothinName",
        "show the recently added books of @nothinName",
        "find the recently added books of @nothinName",
        "what new books are there of @nothinName",
        "do you have any new books listed of @nothinName",
        "I am looking for new books of @nothinName",
        "which books are newly added of @nothinName",
        "could you tell me the books you recently added of @nothinName",
        "new books of @nothinName",
        "most recent books by @nothinName",
        "recent books by @nothinName",
        "latest books of @nothinName",
        "latest books by @nothinName",
        "list all recently added books in @nothinName",
        "show me the recently added books in @nothinName",
        "do you have any new books in @nothinName",
        "can you find recently added books in @nothinName",
        "what books were recently added in @nothinName",
        "I want to know about new books in @nothinName",
        "can you list all the new books in @nothinName",
        "show the recently added books in @nothinName",
        "find the recently added books in @nothinName",
        "what new books are there in @nothinName",
        "do you have any new books listed in @nothinName",
        "I am looking for new books in @nothinName",
        "which books are newly added in @nothinName",
        "could you tell me the books you recently added in @nothinName",
        "new books in @nothinName",
        "most recent books by @nothinName",
        "recent books by @nothinName",
        "latest books of @nothinName",
        "latest books by @nothinName",
        "list all recently added books in @nothinName",
        "show me the recently added books in @nothinName",
        "do you have any new books in @nothinName",
        "can you find recently added books in @nothinName",
        "what books were recently added in @nothinName",
        "I want to know about new books in @nothinName",
        "can you list all the new books in @nothinName",
        "show the recently added books in @nothinName",
        "find the recently added books in @nothinName",
        "what new books are there in @nothinName",
        "do you have any new books listed in @nothinName",
        "I am looking for new books in @nothinName",
        "which books are newly added in @nothinName",
        "could you tell me the books you recently added in @nothinName",
        "new books in @nothinName",
        "most recent books by @nothinName",
        "recent books by @nothinName",
        "latest books by @nothinName",
        "latest books of @nothinName",
        "show books similar to @nothinName",
        "list books that are similar to @nothinName",
        "find books like @nothinName",
        "do you have books similar to @nothinName",
        "can you find books related to @nothinName",
        "what books are like @nothinName",
        "I want to read books similar to @nothinName",
        "can you list books like @nothinName",
        "show books related to @nothinName",
        "find books that are similar to @nothinName",
        "which books are similar to @nothinName",
        "do you have any books like @nothinName",
        "I am looking for books similar to @nothinName",
        "could you tell me the books similar to @nothinName",
        "which books are alike @nothinName",
        "show books similar to @nothinName to renew",
        "Show me books that are similar to @nothinName available for renewal.",
        "What books are like @nothinName that I can renew?",
        "I'm looking for books similar to @nothinName to renew.",
        "Can you recommend books similar to @nothinName for renewal?",
        "Find books akin to @nothinName that I can renew.",
        "I'd like to explore books resembling @nothinName available for renewal.",
        "Could you suggest books related to @nothinName that I can renew?",
        "Are there any books comparable to @nothinName that I can renew?",
        "recommend me books similar to @nothinName",
        "recommend me books like @nothinName",
        "show all books that are about @nothinName",
        "list all books that mention @nothinName",
        "show me books with the keyword @nothinName",
        "do you have books tagged with @nothinName",
        "can you find books with the keyword @nothinName",
        "what books are available with the keyword @nothinName",
        "I want to read books with the keyword @nothinName",
        "can you list books with the keyword @nothinName",
        "show books tagged with @nothinName",
        "find books with the keyword @nothinName",
        "what books are tagged with @nothinName",
        "do you have any books with the keyword @nothinName",
        "I am looking for books with the keyword @nothinName",
        "which books are tagged with @nothinName",
        "could you tell me the books with the keyword @nothinName",
        "list all books that reference @nothinName",
        "show me books that include @nothinName",
        "find books related to @nothinName",
        "books that talk about @nothinName",
        "books that discuss @nothinName",
        "books mentioning @nothinName",
        "list of @nothinName books",
        "What books related to @nothinName can I renew?",
        "Can you show me which books related to @nothinName I can renew?",
        "I'd like to see the books related to @nothinName available for renewal.",
        "Show me the selection of books related to @nothinName I can renew.",
        "Which books related to @nothinName can I renew?",
        "Please list the books related to @nothinName I can renew.",
        "Could you tell me about the books associated with @nothinName available for renewal?",
        "I'm interested in renewing books related to @nothinName. What's available?",
        "What are my options for renewing books associated with @nothinName?",
        "I want to renew books connected to @nothinName. Which ones are available?",
        "list all books on @nothinName",
        "show me books about @nothinName",
        "do you have books on @nothinName",
        "can you find books related to @nothinName",
        "what books are available on @nothinName",
        "I want to read books about @nothinName",
        "can you list books on @nothinName",
        "show books related to @nothinName",
        "find books about @nothinName",
        "what books are about @nothinName",
        "do you have any books on @nothinName",
        "I am looking for books on @nothinName",
        "which books are on @nothinName",
        "could you tell me the books on @nothinName",
        "list all books in the subject of @nothinName",
        "show me books in the subject of @nothinName",
        "do you have books in the subject of @nothinName",
        "can you find books in the subject of @nothinName",
        "what books are available in the subject of @nothinName",
        "I want to read books in the subject of @nothinName",
        "can you list books in the subject of @nothinName",
        "show books in the subject of @nothinName",
        "find books in the subject of @nothinName",
        "what books are in the subject of @nothinName",
        "do you have any books in the subject of @nothinName",
        "I am looking for books in the subject of @nothinName",
        "which books are in the subject of @nothinName",
        "could you tell me the books in the subject of @nothinName",
        "list of @nothinName books",
        "What books from @nothinName can I renew?",
        "Can you show me which books from @nothinName I can renew?",
        "I'd like to see the books from @nothinName available for renewal.",
        "Show me the selection of books from @nothinName I can renew.",
        "Which books from @nothinName can I renew?",
        "Please list the books from @nothinName I can renew.",
        "Could you tell me about the books in the @nothinName category available for renewal?",
        "I'm interested in renewing books from @nothinName. What's available?",
        "What are my options for renewing books in the @nothinName category?",
        "I want to renew books related to @nothinName. Which ones are available?",
        "list all books of @nothinName genre",
        "list all books of genre @nothinName ",
        "show me books in the @nothinName genre",
        "show me books in the genre @nothinName",
        "do you have books in the @nothinName genre",
        "do you have books in the genre @nothinName",
        "Can you find books in the genre categorized as @nothinName?",
        "Can you find books categorized as @nothinName genre?",
        "what books are available in the @nothinName genre",
        "what books are available in the @nothinName genre",
        "I want to read books in the @nothinName genre",
        "I want to read books in the genre @nothinName",
        "can you list books under @nothinName genre",
        "can you list books under genre @nothinName",
        "find books of @nothinName genre",
        "find books of genre @nothinName",
        "what books belong to the @nothinName genre",
        "what books belong to the genre @nothinName",
        "do you have any books in @nothinName genre",
        "do you have any books in genre @nothinName",
        "I am looking for books in the @nothinName genre",
        "I am looking for books in the genre @nothinName",
        "which books are categorized under @nothinName genre",
        "which books are categorized under genre @nothinName",
        "could you tell me the books in the @nothinName genre",
        "could you tell me the books in the genre @nothinName",
        "What books in the genre @nothinName are available for me to renew?",
        "What @nothinName genre books are available for me to renew?",
        "Can you show me which books in the @nothinName genre I can renew?",
        "Can you show me which books in the genre @nothinName I can renew?",
        "I'd like to see the books in the @nothinName genre available for renewal.",
        "I'd like to see the books in the genre @nothinName available for renewal.",
        "Show me the selection of books in the @nothinName genre I can renew.",
        "Show me the selection of books in the genre @nothinName I can renew.",
        "Please list the books in the @nothinName genre I can renew.",
        "Please list the books in the genre @nothinName I can renew.",
        "Could you tell me about the books in the @nothinName genre available for renewal?",
        "Could you tell me about the books in the genre @nothinName available for renewal?",
        "I'm interested in renewing books in the @nothinName genre. What's available?",
        "I'm interested in renewing books in the genre @nothinName. What's available?",
        "What are my options for renewing books in the @nothinName genre?",
        "What are my options for renewing books in the genre @nothinName?",
        "I want to renew books in the @nothinName genre. Which ones are available?",
        "I want to renew books in the genre @nothinName. Which ones are available?",
        "location of @nothinName",
        "shelf of @nothinName",
        "where is @nothinName",
        "how far away is @nothinName",
        "is @nothinName available",
        "is @nothinName present in the library",
        "where can I find @nothinName?",
        "in which section is @nothinName located?",
        "could you tell me the shelf for @nothinName?",
        "how can I locate @nothinName?",
        "do you know the whereabouts of @nothinName?",
        "is @nothinName currently available?",
        "can you confirm if @nothinName is accessible?",
        "is @nothinName in stock?",
        "is @nothinName available for borrowing?",
        "could you check if @nothinName is present in the library?",
        "is @nothinName present",
        "is @nothinName available",
        "do you have @nothinName",
        "where can I find @nothinName to renew",
        "Where can I find @nothinName for renewal?",
        "Can you tell me where @nothinName is located for renewal?",
        "I need to know the location of @nothinName for renewal.",
        "Could you direct me to @nothinName so I can renew it?",
        "Where should I go to renew @nothinName?",
        "I'm looking for @nothinName. Where can I renew it?",
        "I'd like to renew @nothinName. Where is it located?",
        "Please tell me where @nothinName is so I can renew it.",
        "Do you know the whereabouts of @nothinName for renewal?",
        "Can you guide me to @nothinName to renew it?",
        "where can I find @nothinName in order to renew it",
        "what is the location of @nothinName",
        "where is the @nothinName located",
        "@nothinName",

        ),
    mapOf("nothinName" to UnavailableEntity::class.java),
    Language.ENGLISH_US
)

class TotalBookLib : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "show me the total number of books in the library",
            "how many books are in the library",
            "total books in the library",
            "give me the total number of books in the library",
            "what is the total number of books in the library",
            "how many books does the library have",
            "tell me the number of books in the library",
            "what is the total count of books in the library",
            "total books"
        )
    }
}

class LibRR : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "renew borrowed items",
            "how can I renew books I've borrowed",
            "what's the process for renewing borrowed items",
            "where do I return library materials",
            "return borrowed books",
            "procedure for returning items",
            "where can I renew items",
            "return items",
            "renewal and return process",
            "renewal", "return",
            "where should I go to renew my library materials",
            "renewal policies"
        )
    }
}

class LibPolicies : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "borrowing limits",
            "how many items can I borrow",
            "borrowing limit",
            "how long can I keep a book",
            "loan period",
            "borrowing policy",
            "rules for borrowing books",
            "how many books am I allowed to check out",
            "what's the duration for borrowing books",
            "book borrowing policy",
            "libraries policy",
            "policies",
            "borrowing rules"
        )
    }
}

class LibServices : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "services offer",
            "library services",
            "service information",
            "services are available",
            "what are the library's service offerings",
            "libraries services",
            "overview of the library services",
        )
    }
}

class ContinueIntent : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "you can continue now",
            "please proceed",
            "let's move on",
            "continue please",
            "let's continue",
            "let's start again",
            "can you continue",
            "can we continue",
            "can we start",
            "please continue",
            "ok I'm back",
            "I'm back now",
            "We're ready now",
            "okay you can continue"
        )
    }
}

class WakeUpIntent : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "wakeup",
            "furhat",
            "wake up",
            "I'm back",
            "wakey wakey",
            "are you here",
            "are you there",
            "do you hear me",
            "can you hear me",
            "can I talk to you",
            "I want to talk to you",
            "can you wake",
            "can you wake up please",
            "are you awake",
            "can you pick up",
            "can you come back"
        )
    }
}


class StartIntent : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "start",
            "start again",
            "can you restart",
            "can you start over",
            "can we start",
            "start please",
            "time to start",
            "let's go",
            "come on",
            "alright let's go",
            "you can start again"

        )
    }
}

class WaitIntent : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "hold on",
            "wait a bit",
            "chill a bit",
            "wait a little",
            "wait a minute",
            "give me a second",
            "chill for a while",
            "hold on for a while",
            "hold on for a second",
            "wait just one second",
            "hold on for a minute",
            "could you give me a second",
            "give me a second",
            "stop for second,",
            "just wait okay",
            "can you give me a moment",
            "can you relax for a bit",
            "you can just relax okay",
            "just relax",
            "can you wait"
        )
    }
}

class StopTalkingIntent : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "be quiet",
            "shut up",
            "shut your mouth",
            "can you stop talking",
            "stop talking"
        )
    }
}

class NotTalkingToYouIntent : Intent() {
    override fun getExamples(lang: Language): List<String> {
        return listOf(
            "Im not talking to you",
            "im speaking to someone else right now",
            "im talking to someone else"
        )
    }
}