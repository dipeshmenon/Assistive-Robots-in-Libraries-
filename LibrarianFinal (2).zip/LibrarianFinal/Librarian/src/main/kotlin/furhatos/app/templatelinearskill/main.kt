package furhatos.app.templatelinearskill

import furhatos.app.templatelinearskill.flow.Init
import furhatos.flow.kotlin.Flow
import furhatos.skills.Skill
import java.sql.*
import java.util.Properties

class MyLinearSkill : Skill() {
    override fun start() {
        Flow().run(Init)
    }

}

/**
 * Run your skill from here.
 */
fun main(args: Array<String>) {
    Skill.main(args)

}
