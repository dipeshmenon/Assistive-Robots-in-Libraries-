# Skill
Template Linear skill
Main Author: Nils Hagberg, Furhat Robotics

## Description
This is a skill template for creating interactions with a simple linear flow. 

See [the docs](https://docs.furhat.io/skills/#the-contents-of-a-skill) for a breakdown of the common content. 
For more example skills go to [our Github](https://github.com/FurhatRobotics/)

## Usage
Max number of users is set to: 2
Default interaction distance is set to: 1 m
No other specific requirements.